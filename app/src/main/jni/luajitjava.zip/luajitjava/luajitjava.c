/******************************************************************************
* $Id$
* Copyright (C) 2026-2099 DifierLine.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************/

/***************************************************************************
*
* $ED
*    This module is the implementation of luajava's dinamic library.
*    In this module lua's functions are exported to be used in java by jni,
*    and also the functions that will be used and exported to lua so that
*    Java Objects' functions can be called.
*
*****************************************************************************/

#include "luajava.h"
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>

#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"

static inline void luaL_requiref_compat(luajitcore_State *L, const char *modname, luajitcore_CFunction openf, int glb) {
    luajitcore_pushcfunction(L, openf);
    luajitcore_call(L, 0, 0);
    if (glb) {
        luajitcore_pushvalue(L, -1);
        luajitcore_setglobal(L, modname);
    }
    luajitcore_getfield(L, LUA_GLOBALSINDEX, "_LOADED");
    luajitcore_pushvalue(L, -2);
    luajitcore_setfield(L, -2, modname);
    luajitcore_pop(L, 2);
}

#define luaL_requiref luaL_requiref_compat

static inline int luajitcore_isinteger_compat(luajitcore_State *L, int idx) {
    int isnum = 0;
    luajitcore_Integer val = luajitcore_tointegerx(L, idx, &isnum);
    (void)val;
    return isnum;
}
#define luajitcore_isinteger luajitcore_isinteger_compat

static inline int luajitcore_compare_compat(luajitcore_State *L, int idx1, int idx2, int op);
static inline size_t luajitcore_rawlen_compat(luajitcore_State *L, int idx);
static inline void luajitcore_rotate_compat(luajitcore_State *L, int idx, int n);
static inline const char *luaL_tolstring_compat(luajitcore_State *L, int idx, size_t *len);
static inline int luajitcore_getuservalue_compat(luajitcore_State *L, int idx);
static inline void luajitcore_setuservalue_compat(luajitcore_State *L, int idx);
static inline int luajitcore_geti_compat(luajitcore_State *L, int idx, luajitcore_Integer n);
static inline int luajitcore_rawgeti_compat(luajitcore_State *L, int idx, luajitcore_Integer n);

#ifndef LUA_OPEQ
#define LUA_OPEQ 0
#endif
#ifndef LUA_OPLT
#define LUA_OPLT 1
#endif
#ifndef LUA_OPLE
#define LUA_OPLE 2
#endif

static inline int luajitcore_compare_compat(luajitcore_State *L, int idx1, int idx2, int op) {
    int result = 0;
    switch (op) {
        case LUA_OPEQ:
            result = luajitcore_equal(L, idx1, idx2);
            break;
        case LUA_OPLT:
            result = luajitcore_lessthan(L, idx1, idx2);
            break;
        case LUA_OPLE:
            result = luajitcore_equal(L, idx1, idx2) || luajitcore_lessthan(L, idx1, idx2);
            break;
    }
    return result;
}
#define luajitcore_compare luajitcore_compare_compat

static inline size_t luajitcore_rawlen_compat(luajitcore_State *L, int idx) {
    return luajitcore_objlen(L, idx);
}
#define luajitcore_rawlen luajitcore_rawlen_compat

static inline void luajitcore_rotate_compat(luajitcore_State *L, int idx, int n) {
    int top = luajitcore_gettop(L);
    if (n > 0) {
        for (int i = 0; i < n; i++) {
            luajitcore_insert(L, idx);
            luajitcore_remove(L, idx + 1);
        }
    } else if (n < 0) {
        for (int i = 0; i < -n; i++) {
            luajitcore_insert(L, top);
            luajitcore_remove(L, top - 1);
        }
    }
}
#define luajitcore_rotate luajitcore_rotate_compat

static inline const char *luaL_tolstring_compat(luajitcore_State *L, int idx, size_t *len) {
    return luajitcore_tolstring(L, idx, len);
}
#define luaL_tolstring luaL_tolstring_compat

static inline int luajitcore_getuservalue_compat(luajitcore_State *L, int idx) {
    luajitcore_getfenv(L, idx);
    return luajitcore_type(L, -1);
}
#define luajitcore_getuservalue luajitcore_getuservalue_compat

static inline void luajitcore_setuservalue_compat(luajitcore_State *L, int idx) {
    luajitcore_setfenv(L, idx);
}
#define luajitcore_setuservalue luajitcore_setuservalue_compat

static inline int luajitcore_geti_compat(luajitcore_State *L, int idx, luajitcore_Integer n) {
    luajitcore_pushinteger(L, n);
    luajitcore_gettable(L, idx);
    return luajitcore_type(L, -1);
}
#define luajitcore_geti luajitcore_geti_compat

static inline int luajitcore_rawgeti_compat(luajitcore_State *L, int idx, luajitcore_Integer n) {
    luajitcore_rawgeti(L, idx, n);
    return luajitcore_type(L, -1);
}
#define luajitcore_rawgeti luajitcore_rawgeti_compat

static inline void luajitcore_seti_compat(luajitcore_State *L, int idx, luajitcore_Integer n) {
    luajitcore_pushinteger(L, n);
    luajitcore_insert(L, -2);
    luajitcore_settable(L, idx);
}
#define luajitcore_seti luajitcore_seti_compat

static inline void luajitcore_pushglobaltable_compat(luajitcore_State *L) {
    luajitcore_pushvalue(L, LUA_GLOBALSINDEX);
}
#define luajitcore_pushglobaltable luajitcore_pushglobaltable_compat

static inline int luajitcore_absindex_compat(luajitcore_State *L, int idx) {
    if (idx > 0) return idx;
    if (idx > LUA_REGISTRYINDEX) return luajitcore_gettop(L) + 1 + idx;
    return idx;
}
#define luajitcore_absindex luajitcore_absindex_compat

static inline int luajitcore_dump_compat(luajitcore_State *L, luajitcore_Writer writer, void *data) {
    return luajitcore_dump(L, writer, data);
}
#define luajitcore_dump luajitcore_dump_compat

#ifndef LUA_OPEQ
#define LUA_OPEQ 0
#endif
#ifndef LUA_OPLT
#define LUA_OPLT 1
#endif
#ifndef LUA_OPLE
#define LUA_OPLE 2
#endif

/* Call metamethod name */
#define LUACALLMETAMETHODTAG "__call"
#define LUATOSTRINGMETAMETHODTAG "__tostring"
#define LUALENMETAMETHODTAG "__len"

#include <android/log.h>
#include <memory.h>
#include <zlib.h>

#define LOG_TAG "lua"
#define LOGD(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)


/* Constant that is used to index the JNI Environment */
#define LUAJAVAJNIENVTAG "_JNIEnv"
/* Defines the lua State Index Property Name */
#define LUAJAVASTATEINDEX "_LuaJavaStateIndex"
/* Defines wheter the metatable is of a java Object */
#define LUAJAVAOBJECTIND "__IsJavaObject"
/* Index metamethod name */
#define LUAINDEXMETAMETHODTAG "__index"
/* New index metamethod name */
#define LUANEWINDEXMETAMETHODTAG "__newindex"
/* Garbage collector metamethod name */
#define LUAGCMETAMETHODTAG "__gc"
/* Constant that defines where in the metatable should I place the function
   name */
#define LUAJAVAOBJECTMETA "JavaObject"

#define LUAJAVAOBJECT "__Object"

static jclass throwable_class = NULL;
static jmethodID get_message_method = NULL;
static jmethodID throwable_tostring_method = NULL;

static jclass java_function_class = NULL;
static jmethodID java_function_method = NULL;

static jclass luajava_api_class = NULL;
static jclass java_lang_class = NULL;
static jclass java_string_class = NULL;

static jmethodID object_index_method = NULL;
static jmethodID call_method = NULL;
static jmethodID object_newindex_method = NULL;
static jmethodID new_array_method = NULL;
static jmethodID new_multiarray_method = NULL;
static jmethodID get_array_method = NULL;
static jmethodID set_array_method = NULL;
static jmethodID bind_class_method = NULL;
static jmethodID create_proxy_method = NULL;
static jmethodID create_array_method = NULL;
static jmethodID java_create_method = NULL;
static jmethodID java_new_method = NULL;
static jmethodID java_override_method = NULL;
static jmethodID object_call_method = NULL;
static jmethodID java_newinstance_method = NULL;
static jmethodID as_table_method = NULL;
static jmethodID to_string_method = NULL;
static jmethodID get_type_method = NULL;
static jmethodID object_length_method = NULL;
static jmethodID object_instanceof_method = NULL;
static jmethodID string_init_method = NULL;
static jmethodID string_getbytes_method = NULL;
static jmethodID class_getname_method = NULL;
static jmethodID object_equals_method = NULL;
static jmethodID java_gc_method = NULL;
static jmethodID java_close_method = NULL;
static jmethodID get_object_method = NULL;

static jmethodID java_to_jobject_method = NULL;

static int objectIndex(luajitcore_State *L);

static int callMethod(luajitcore_State *L);

static int objectNewIndex(luajitcore_State *L);

static int javaBindClass(luajitcore_State *L);

static int createProxy(luajitcore_State *L);

static int newArray(luajitcore_State *L);

static int createArray(luajitcore_State *L);

static int javaNew(luajitcore_State *L);

static int javaNewInstance(luajitcore_State *L);

static int javaLoadLib(luajitcore_State *L);

static int asTable(luajitcore_State *L);

static int javaToString(luajitcore_State *L);

static int javaObjectLength(luajitcore_State *L);

static int coding(luajitcore_State *L);

static luajitcore_State *getStateFromCPtr(JNIEnv *env, jlong cptr);

static int luaJavaFunctionCall(luajitcore_State *L);

void pushJNIEnv(JNIEnv *env, luajitcore_State *L);

int pushJavaObject(luajitcore_State *L, const char *name,int idx,int isclass);

JNIEnv *checkEnv(luajitcore_State *L);

jlong checkIndex(luajitcore_State *L);

java_object *checkJavaObject(luajitcore_State *L, int idx);

jobject *toJavaObject(luajitcore_State *L, int idx);

void checkError(JNIEnv *javaEnv, luajitcore_State *L);

static int gc(luajitcore_State *L);
static int jclose(luajitcore_State *L);

JNIEnv *getEnvFromState(luajitcore_State *L);

int isJavaObject(luajitcore_State *L, int idx);

static int javaJITSetMode(luajitcore_State *L);

static int javaJITProfileStart(luajitcore_State *L);

static int javaJITProfileStop(luajitcore_State *L);

static int javaJITProfileDumpStack(luajitcore_State *L);


JNIEnv *checkEnv(luajitcore_State *L) {
    JNIEnv *javaEnv = (JNIEnv *) 0;
    luajitcore_pushstring(L, LUAJAVAJNIENVTAG);
    luajitcore_rawget(L, LUA_REGISTRYINDEX);

    if (luajitcore_isuserdata(L, -1))
        javaEnv = *(JNIEnv **) luajitcore_touserdata(L, -1);
    luajitcore_pop(L, 1);
    if (!javaEnv)
        luaL_error(L, "Invalid JNI Environment.");
    return javaEnv;
}

jlong checkIndex(luajitcore_State *L) {
    return (jlong) L;
}

java_object *checkJavaObject(luajitcore_State *L, int idx) {
    //if (!isJavaObject(L, idx))
    //luaL_typerror(L, idx, "java Object");
    //return (jobject *)luajitcore_touserdata(L, idx);
    java_object *obj;
    obj = (java_object *) luaL_checkudata(L, idx, LUAJAVAOBJECTMETA);
    if (obj == NULL) {
        luaL_argerror(L, idx, "JavaObject expected, got null");
    }
    //LOGD("checkJavaObject %s %d %d",obj->name,obj->index,obj->type);
    return obj;
}

jobject *toJavaObject(luajitcore_State *L, int idx){
    JNIEnv *env = checkEnv(L);
    jlong stateIndex = checkIndex(L);
    java_object *obj= (java_object *) luaL_checkudata(L, idx, LUAJAVAOBJECTMETA);
    if (obj == NULL) {
        luaL_argerror(L, idx, "JavaObject expected, got null");
    }
    //LOGD("checkJavaObject %s %d %d",obj->name,obj->index,obj->type);
    (void)obj->index; // 显式忽略未使用的表达式
    jobject ret = (*env)->CallStaticObjectMethod(env, luajava_api_class,
                                          get_object_method,
                                          stateIndex, obj->index);
    checkError(env, L);
    jobject jobj = (*env)->NewGlobalRef(env, ret);
    (*env)->DeleteLocalRef(env,ret);
    return jobj;
}

void checkError(JNIEnv *javaEnv, luajitcore_State *L) {
    jthrowable exp = (*javaEnv)->ExceptionOccurred(javaEnv);

    /* Handles exception */
    if (exp != NULL) {
        jobject jstr;
        const char *cStr;

        (*javaEnv)->ExceptionClear(javaEnv);
        jstr = (*javaEnv)->CallObjectMethod(javaEnv, exp, get_message_method);

        if (jstr == NULL) {
            if (throwable_tostring_method == NULL)
                throwable_tostring_method = (*javaEnv)->GetMethodID(javaEnv, throwable_class,
                                                                    "toString",
                                                                    "()Ljava/lang/String;");
            jstr = (*javaEnv)->CallObjectMethod(javaEnv, exp, throwable_tostring_method);
        }

        cStr = (*javaEnv)->GetStringUTFChars(javaEnv, jstr, NULL);
        //luajitcore_settop(L, 0);
        luajitcore_pushstring(L, cStr);

        (*javaEnv)->ReleaseStringUTFChars(javaEnv, jstr, cStr);
        (*javaEnv)->DeleteLocalRef(javaEnv, exp);
        (*javaEnv)->DeleteLocalRef(javaEnv, jstr);

        luajitcore_error(L);
    }
}

/********************* Implementations ***************************/

static void init(JNIEnv *javaEnv, luajitcore_State *L) {
    jclass tempClass;

    if (luajava_api_class == NULL) {
        tempClass = (*javaEnv)->FindClass(javaEnv, "com/difierline/luajitcore/luajit/LuaJavaAPI");

        if (tempClass == NULL) {
            fprintf(stderr, "Could not find LuaJavaAPI class\n");
            exit(1);
        }

        if ((luajava_api_class = (*javaEnv)->NewGlobalRef(javaEnv, tempClass)) == NULL) {
            fprintf(stderr, "Could not bind to LuaJavaAPI class\n");
            exit(1);
        }
        (*javaEnv)->DeleteLocalRef(javaEnv, tempClass);
    }

    if (java_function_class == NULL) {
        tempClass = (*javaEnv)->FindClass(javaEnv, "com/difierline/luajitcore/luajit/JavaFunction");

        if (tempClass == NULL) {
            fprintf(stderr, "Could not find JavaFunction interface\n");
            exit(1);
        }

        if ((java_function_class = (*javaEnv)->NewGlobalRef(javaEnv, tempClass)) == NULL) {
            fprintf(stderr, "Could not bind to JavaFunction interface\n");
            exit(1);
        }
        (*javaEnv)->DeleteLocalRef(javaEnv, tempClass);
    }

    if (java_function_method == NULL) {
        java_function_method =
                (*javaEnv)->GetMethodID(javaEnv, java_function_class, "execute", "()I");
        if (!java_function_method) {
            fprintf(stderr, "Could not find <execute> method in JavaFunction\n");
            exit(1);
        }
    }

    if (throwable_class == NULL) {
        tempClass = (*javaEnv)->FindClass(javaEnv, "java/lang/Throwable");

        if (tempClass == NULL) {
            fprintf(stderr, "Error. Couldn't bind java class java.lang.Throwable\n");
            exit(1);
        }

        throwable_class = (*javaEnv)->NewGlobalRef(javaEnv, tempClass);
        (*javaEnv)->DeleteLocalRef(javaEnv, tempClass);

        if (throwable_class == NULL) {
            fprintf(stderr, "Error. Couldn't bind java class java.lang.Throwable\n");
            exit(1);
        }
    }

    if (get_message_method == NULL) {
        get_message_method = (*javaEnv)->GetMethodID(javaEnv, throwable_class, "getMessage",
                                                     "()Ljava/lang/String;");

        if (get_message_method == NULL) {
            fprintf(stderr,
                    "Could not find <getMessage> method in java.lang.Throwable\n");
            exit(1);
        }
    }

    if (java_lang_class == NULL) {
        tempClass = (*javaEnv)->FindClass(javaEnv, "java/lang/Class");

        if (tempClass == NULL) {
            fprintf(stderr, "Error. Coundn't bind java class java.lang.Class\n");
            exit(1);
        }

        java_lang_class = (*javaEnv)->NewGlobalRef(javaEnv, tempClass);
        (*javaEnv)->DeleteLocalRef(javaEnv, tempClass);

        if (java_lang_class == NULL) {
            fprintf(stderr, "Error. Couldn't bind java class java.lang.Throwable\n");
            exit(1);
        }
    }

    if (java_string_class == NULL) {
        tempClass = (*javaEnv)->FindClass(javaEnv, "java/lang/String");

        if (tempClass == NULL) {
            fprintf(stderr, "Could not find String class\n");
            exit(1);
        }

        if ((java_string_class = (*javaEnv)->NewGlobalRef(javaEnv, tempClass)) == NULL) {
            fprintf(stderr, "Could not bind to String class\n");
            exit(1);
        }
        (*javaEnv)->DeleteLocalRef(javaEnv, tempClass);
    }

    /* Gets method */
    if (call_method == NULL)
        call_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "callMethod",
                "(JILjava/lang/String;)I");
    if (object_index_method == NULL)
        object_index_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "objectIndex",
                "(JILjava/lang/String;I)I");
    if (object_newindex_method == NULL)
        object_newindex_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "objectNewIndex",
                "(JILjava/lang/String;I)I");
    if (new_array_method == NULL)
        new_array_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "newArray", "(JII)I");
    if (new_multiarray_method == NULL)
        new_multiarray_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "newArray", "(JI)I");
    if (get_array_method == NULL)
        get_array_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "getArrayValue", "(JII)I");
    if (set_array_method == NULL)
        set_array_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "setArrayValue", "(JII)I");
    if (bind_class_method == NULL)
        bind_class_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaBindClass",
                "(JLjava/lang/String;)I");
    if (create_proxy_method == NULL)
        create_proxy_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "createProxy", "(JLjava/lang/String;)I");
    if (create_array_method == NULL)
        create_array_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "createArray", "(JLjava/lang/String;)I");
    if (java_create_method == NULL)
        java_create_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaCreate", "(JI)I");
    if (java_new_method == NULL)
        java_new_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaNew", "(JI)I");
    if (java_override_method == NULL)
        java_override_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaOverride", "(JI)I");
    if (object_call_method == NULL)
        object_call_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "objectCall", "(JI)I");
    if (java_newinstance_method == NULL)
        java_newinstance_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaNewInstance",
                "(JLjava/lang/String;)I");
    if (as_table_method == NULL)
        as_table_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "asTable", "(JI)I");
    if (to_string_method == NULL)
        to_string_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaToString", "(JI)I");
    if (get_type_method == NULL)
        get_type_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaGetType", "(JI)I");
    if (object_length_method == NULL)
        object_length_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaObjectLength",
                "(JI)I");
    if (object_equals_method == NULL)
        object_equals_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaEquals",
                "(JII)I");
    if (object_instanceof_method == NULL)
        object_instanceof_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaInstanceof",
                "(JII)I");
    if (java_gc_method == NULL)
        java_gc_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaGc", "(JI)V");
    if (java_close_method == NULL)
        java_close_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaClose", "(JI)V");
    if (get_object_method == NULL)
        get_object_method = (*javaEnv)->GetStaticMethodID(
                javaEnv, luajava_api_class, "javaGetObject", "(JI)Ljava/lang/Object;");

    if (string_init_method == NULL)
        string_init_method = (*javaEnv)->GetMethodID(
                javaEnv, java_string_class, "<init>", "([BLjava/lang/String;)V");
    if (string_getbytes_method == NULL)
        string_getbytes_method = (*javaEnv)->GetMethodID(
                javaEnv, java_string_class, "getBytes", "(Ljava/lang/String;)[B");
    if (class_getname_method == NULL)
        class_getname_method = (*javaEnv)->GetMethodID(
                javaEnv, java_lang_class, "getName", "()Ljava/lang/String;");
    checkError(javaEnv, L);
}

#define NAME "__name"

static inline const char *getObjectName(luajitcore_State *L, JNIEnv *env,
                                        jobject obj) {
    const char *name;

    luajitcore_pushstring(L, NAME);
    luajitcore_rawget(L, -2);
    if (luajitcore_isnil(L, -1)) {
        luajitcore_pop(L, 1);
        jclass cls;
        char c;
        if ((*env)->IsInstanceOf(env, obj, java_lang_class) == JNI_TRUE) {
            c = '.';
            cls = (jclass) obj;
        } else {
            c = '@';
            cls = (*env)->GetObjectClass(env, obj);
            checkError(env, L);
        }

        /*luajitcore_pushstring(L, "class");
        pushJavaObject(L,cls);
        luajitcore_rawset(L, -3);*/

        jstring jstr = (*env)->CallObjectMethod(env, cls, class_getname_method);
        checkError(env, L);
        const char *cStr = (*env)->GetStringUTFChars(env, jstr, NULL);
        luajitcore_pushstring(L, NAME);
        name = luajitcore_pushfstring(L, "%s%c", cStr, c);
        luajitcore_rawset(L, -3);

        (*env)->ReleaseStringUTFChars(env, jstr, cStr);
        (*env)->DeleteLocalRef(env, jstr);

        if (c == '@')
            (*env)->DeleteLocalRef(env, cls);
    } else {
        name = luajitcore_tostring(L, -1);
        luajitcore_pop(L, 1);
    }
    return name;
}

/***************************************************************************
*
*  Function: objectIndex
*  ****/

int objectIndex(luajitcore_State *L) {
    jlong stateIndex;
    const char *key;
    const char *tag;
    jint ret = 0;
    java_object *obj;
    jstring str;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* Gets the object reference */
    obj = checkJavaObject(L, 1);
    /* if key is number get array value, if key is string get object field or
     * method. */
    if (luajitcore_type(L, 2) == LUA_TNUMBER) {
        luajitcore_Number akey = luajitcore_tonumber(L, 2);
        jmethodID method;
        if (obj->type)
            method = new_array_method;
        else
            method = get_array_method;

        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class, method,
                                              stateIndex, obj->index, (jint) akey);
        checkError(javaEnv, L);
        return 1;
    } else if (luajitcore_type(L, 2) == LUA_TSTRING) {
        key = luajitcore_tostring(L, 2);
        luajitcore_getuservalue(L,1);
        const char *name=luajitcore_tostring(L,-1);
        luajitcore_pop(L,1);
        luajitcore_getmetatable(L, 1);
        /* lua stack：1,object;2,key;3,metatable */
        luajitcore_rawgeti(L, 3, (long long) obj->index);
        if (luajitcore_isnil(L, -1)) {
            luajitcore_pop(L, 1);
            luajitcore_newtable(L);
            luajitcore_pushvalue(L, -1);
            luajitcore_rawseti(L, 3, (long long) obj);
        }
        luajitcore_pushvalue(L, 2);
        luajitcore_rawget(L, -2);
        int mtype = luajitcore_type(L, -1);
        //int mtype = luajitcore_type(L, -1);
        if (mtype == LUA_TFUNCTION) {
            luajitcore_pushvalue(L, 1);
            luajitcore_setupvalue(L, -2, 2);
            return 1;
        }
        if (mtype != LUA_TNIL)
            return 1;

        luajitcore_pop(L, 1);
        //const char *name = obj->name;//getObjectName(L, javaEnv, *obj);
        //luaL_getsubtable(L, 3, "_CACHE");
        luajitcore_rawgeti(L, 3, 0);
        if (luajitcore_isnil(L, -1)) {
            luajitcore_pop(L, 1);
            luajitcore_newtable(L);
            luajitcore_pushvalue(L, -1);
            luajitcore_rawseti(L, 3, 0);
        }
        luajitcore_remove(L, 3);
        tag = luajitcore_pushfstring(L,  "%s%c%s", name,obj->type?'.':'@', key);
        //LOGD("objectIndex: %s %d %d %s",obj->name,obj->index,obj->type,tag);
        /* lua stack：1,object;2,key;3,objtable;4,cache;5,tag */

        luajitcore_pushvalue(L, -1);
        luajitcore_rawget(L, 4);
        int ctype = luajitcore_type(L, -1);
        int type = 0;
        if (ctype == LUA_TNUMBER)
            type = (int) luajitcore_tointeger(L, -1);

        luajitcore_pop(L, 1);
        //luajitcore_pushstring(L, tag);

        if (type != 2) {
            str = (*javaEnv)->NewStringUTF(javaEnv, key);
            ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                                  object_index_method,
                                                  stateIndex, obj->index, str, type);
            (*javaEnv)->DeleteLocalRef(javaEnv, str);
            checkError(javaEnv, L);
        }

        if (ctype == LUA_TNIL) {
            luajitcore_pushvalue(L, 5);
            //luajitcore_pushstring(L, tag);
            luajitcore_pushinteger(L, ret);
            luajitcore_rawset(L, 4);
        }

        if (ret == 2 || type == 2) {
            //luajitcore_pushinteger(L, (int)obj);
            luajitcore_pushvalue(L, 1);
            luajitcore_pushcclosure(L, &callMethod, 2);
            luajitcore_pushvalue(L, 2);
            luajitcore_pushvalue(L, -2);
            luajitcore_rawset(L, 3);
        } else if (ret == 3 || ret == 5) {
            luajitcore_pushvalue(L, 2);
            luajitcore_pushvalue(L, -2);
            luajitcore_rawset(L, 3);
        } else if (ret == 0) {
            luaL_error(L, "%s is not a field or mothod", tag);
        }

    } else {
        luajitcore_pushstring(L, "Invalid object index. Must be integer or string.");
        luajitcore_error(L);
    }
    return 1;
}

/***************************************************************************
*
*  Function: callMethod
*  ****/

int callMethod(luajitcore_State *L) {
    jlong stateIndex;
    java_object *obj;
    const char *methodName;
    jint ret;
    jstring str;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* Gets the methodName */
    methodName = luajitcore_tostring(L, luajitcore_upvalueindex(1));

    /* Gets the object reference */
    int udx = luajitcore_upvalueindex(2);
    //obj = checkJavaObject(L, udx);
    //checkJavaObject(L, luajitcore_upvalueindex(1));
    //obj = (jobject*)(int)luajitcore_tointeger(L, luajitcore_upvalueindex(2));
    obj = (java_object *) luaL_testudata(L, udx, LUAJAVAOBJECTMETA);
    if (obj == NULL) {
        luaL_error(L, "can not call the function %s", methodName);
    }

    str = (*javaEnv)->NewStringUTF(javaEnv, methodName);

    ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class, call_method,
                                          stateIndex, obj->index, str);
    (*javaEnv)->DeleteLocalRef(javaEnv, str);
    checkError(javaEnv, L);

    /* if no ret, return self */
    if (ret == 0) {
        luajitcore_pushvalue(L, udx);
        ret = 1;
    }

    /* clear upvalue ref */
    luajitcore_pushnil(L);
    luajitcore_replace(L, udx);
    /* pushes new object into lua stack */
    return ret;
}

/***************************************************************************
*
*  Function: objectNewIndex
*  ****/

int objectNewIndex(luajitcore_State *L) {
    jlong stateIndex;
    java_object *obj;
    const char *fieldName;
    const char *tag;
    luajitcore_Number key;
    jstring str;
    jint ret;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the object reference */
    obj = checkJavaObject(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* if key is number set array value, if key is string set object field value.
     */
    if (luajitcore_type(L, 2) == LUA_TNUMBER) {
        key = luajitcore_tonumber(L, 2);
        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              set_array_method, stateIndex,
                                              obj->index, (jint) key);
        checkError(javaEnv, L);
    } else if (luajitcore_type(L, 2) == LUA_TSTRING) {
        /* Gets the field Name */
        fieldName = luajitcore_tostring(L, 2);
        luajitcore_getuservalue(L,1);
        const char *name=luajitcore_tostring(L,-1);
        luajitcore_pop(L,1);
        luajitcore_getmetatable(L, 1);

        /* lua stack：1,object;2,key;3,value;4,metatable */
        luajitcore_rawgeti(L, 4, (long long) obj);
        if (luajitcore_isnil(L, -1)) {
            luajitcore_pop(L, 1);
            luajitcore_newtable(L);
            luajitcore_pushvalue(L, -1);
            luajitcore_rawseti(L, 4, (long long) obj);
        }
        //const char *name = obj->name;//getObjectName(L, javaEnv, *obj);
        //luaL_getsubtable(L, 3, "_CACHE");
        luajitcore_rawgeti(L, 4, 0);
        if (luajitcore_isnil(L, -1)) {
            luajitcore_pop(L, 1);
            luajitcore_newtable(L);
            luajitcore_pushvalue(L, -1);
            luajitcore_rawseti(L, 4, 0);
        }
        luajitcore_remove(L, 4);
        tag = luajitcore_pushfstring(L, "%s%c%s ", name,obj->type?'.':'@', fieldName);
        /* lua stack：1,object;2,key;3,value;4,objtable;5,cache;6,tag */

        //LOGD("objectNewIndex: %s %d %d %s",obj->name,obj->index,obj->type,tag);
        luajitcore_pushvalue(L, -1);
        luajitcore_rawget(L, 5);
        int ctype = luajitcore_type(L, -1);
        int type = 0;
        if (ctype == LUA_TNUMBER)
            type = (int) luajitcore_tointeger(L, -1);

        luajitcore_pop(L, 1);

        luajitcore_pushvalue(L, 3);
        luajitcore_remove(L, 3);

        str = (*javaEnv)->NewStringUTF(javaEnv, fieldName);

        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              object_newindex_method,
                                              stateIndex, obj->index, str, type);
        if (ctype == LUA_TNIL) {
            luajitcore_pushvalue(L, 5);
            //luajitcore_pushstring(L, tag);
            luajitcore_pushinteger(L, ret);
            luajitcore_rawset(L, 4);
        }
        if (ret == 0)
            luaL_error(L, "%s is not a field", tag);
        (*javaEnv)->DeleteLocalRef(javaEnv, str);
        checkError(javaEnv, L);
    } else {
        luajitcore_pushstring(L, "Invalid object index. Must be integer or string.");
        luajitcore_error(L);
    }
    return 0;
}

/***************************************************************************
*
*  Function: gc
*  ****/

int gc(luajitcore_State *L) {
    java_object *pObj;
    JNIEnv *javaEnv;
    if (!isJavaObject(L, 1)) {
        return 0;
    }
    /* Gets the luaState index */
    jlong stateIndex = checkIndex(L);

    pObj = (java_object *) luajitcore_touserdata(L, 1);
    luajitcore_getmetatable(L, 1);
    luajitcore_pushnil(L);
    luajitcore_rawseti(L, -2, (long long) pObj);
    luajitcore_pop(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);
    (*javaEnv)->CallStaticVoidMethod(javaEnv, luajava_api_class,
                                     java_gc_method, stateIndex,
                                     pObj->index);
    checkError(javaEnv, L);
    //*pObj = NULL;
    return 0;
}

int jclose(luajitcore_State *L) {
    java_object *pObj;
    JNIEnv *javaEnv;
    if (!isJavaObject(L, 1)) {
        return 0;
    }
    jlong stateIndex = checkIndex(L);

    pObj = (java_object *) luajitcore_touserdata(L, 1);
    luajitcore_getmetatable(L, 1);
    luajitcore_pushnil(L);
    luajitcore_rawseti(L, -2, (long long) pObj);
    luajitcore_pop(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);
    (*javaEnv)->CallStaticVoidMethod(javaEnv, luajava_api_class,
                                     java_close_method, stateIndex,
                                     pObj->index);
    checkError(javaEnv, L);
    //*pObj = NULL;
    return 0;
}

/***************************************************************************
*
*  Function: javaBindClass
*  ****/

int javaBindClass(luajitcore_State *L) {
    int top;
    jlong stateIndex;
    const char *className;
    jstring javaClassName;
    int ret;
    JNIEnv *javaEnv;

    top = luajitcore_gettop(L);

    if (top != 1) {
        luaL_error(
                L, "Error. Function javaBindClass received %d arguments, expected 1.",
                top);
    }
    stateIndex = checkIndex(L);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* get the string parameter */
    className = luaL_checkstring(L, 1);

    javaClassName = (*javaEnv)->NewStringUTF(javaEnv, className);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, bind_class_method, stateIndex, javaClassName);

    (*javaEnv)->DeleteLocalRef(javaEnv, javaClassName);
    checkError(javaEnv, L);
    return 1;
}

/***************************************************************************
*
*  Function: createProxy
*  ****/
int createProxy(luajitcore_State *L) {
    jint ret;
    jlong stateIndex;
    const char *impl;
    jstring str;
    JNIEnv *javaEnv;

    if (luajitcore_gettop(L) != 2) {
        luajitcore_pushstring(L, "Error. Function createProxy expects 2 arguments.");
        luajitcore_error(L);
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    luaL_checktype(L, 2, LUA_TTABLE);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    impl = luaL_checkstring(L, 1);

    str = (*javaEnv)->NewStringUTF(javaEnv, impl);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, create_proxy_method, stateIndex, str);

    (*javaEnv)->DeleteLocalRef(javaEnv, str);
    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: createProxy
*  ****/
int newArray(luajitcore_State *L) {
    jint ret;
    jlong stateIndex;
    java_object *clazz;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* Gets the object reference */
    clazz = checkJavaObject(L, 1);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, new_multiarray_method, stateIndex, clazz->index);

    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: createArray
*  ****/
int createArray(luajitcore_State *L) {
    jint ret;
    jlong stateIndex;
    const char *className;
    jstring str;
    JNIEnv *javaEnv;

    if (luajitcore_gettop(L) != 2) {
        luajitcore_pushstring(L, "Error. Function createProxy expects 2 arguments.");
        luajitcore_error(L);
    }


    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    luaL_checktype(L, 2, LUA_TTABLE);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    className = luaL_checkstring(L, 1);

    str = (*javaEnv)->NewStringUTF(javaEnv, className);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, create_array_method, stateIndex, str);

    (*javaEnv)->DeleteLocalRef(javaEnv, str);
    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaNew
*  ****/

int javaNew(luajitcore_State *L) {
    int top;
    jint ret;
    java_object *classInstance;
    jlong stateIndex;
    JNIEnv *javaEnv;
    top = luajitcore_gettop(L);

    if (top == 0) {
        luajitcore_pushstring(L, "Error. Invalid number of parameters.");
        luajitcore_error(L);
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Class reference */
    classInstance = checkJavaObject(L, 1);
    //LOGD("javaNew %s %d %d",classInstance->name,classInstance->index,classInstance->type);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    if (classInstance->type==0) {
        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              object_call_method, stateIndex,
                                              classInstance->index);
        checkError(javaEnv, L);
        if (ret == 0) {
            luajitcore_pushstring(L, "Can not call a Java Object.");
            luajitcore_error(L);
        }
    }
        /* if arg is table create array or interface, else create calss instance. */
    else if (luajitcore_type(L, 2) == LUA_TTABLE && top == 2) {
        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              java_create_method, stateIndex,
                                              classInstance->index);
        checkError(javaEnv, L);
    } else {
        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              java_new_method, stateIndex,
                                              classInstance->index);
        checkError(javaEnv, L);
    }
    return ret;
}

int javaOverride(luajitcore_State *L) {
    int top;
    jint ret = 0;
    java_object *classInstance;
    jlong stateIndex;
    JNIEnv *javaEnv;

    top = luajitcore_gettop(L);

    if (top == 0) {
        luajitcore_pushstring(L, "Error. Invalid number of parameters.");
        luajitcore_error(L);
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Class reference */
    classInstance = checkJavaObject(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    if (classInstance->type == JNI_FALSE) {
            luajitcore_pushstring(L, "Can not Override a Java Object.");
            luajitcore_error(L);
    }
        /* if arg is table create array or interface, else create calss instance. */
    else if (luajitcore_type(L, 2) == LUA_TTABLE) {
        ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                              java_override_method, stateIndex,
                                              classInstance->index);
        checkError(javaEnv, L);
    } else {
        luaL_typerror(L,2,"table");
    }
    return ret;
}
/***************************************************************************
*
*  Function: javaNewInstance
*  ****/

int javaNewInstance(luajitcore_State *L) {
    jint ret;
    const char *className;
    jstring javaClassName;
    jlong stateIndex;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* get the string parameter */
    className = luaL_checkstring(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    javaClassName = (*javaEnv)->NewStringUTF(javaEnv, className);

    ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class,
                                          java_newinstance_method,
                                          stateIndex, javaClassName);

    (*javaEnv)->DeleteLocalRef(javaEnv, javaClassName);
    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaLoadLib
*  ****/

int javaLoadLib(luajitcore_State *L) {
    jint ret;
    int top;
    const char *className, *methodName;
    jlong stateIndex;
    jmethodID method;
    jstring javaClassName, javaMethodName;
    JNIEnv *javaEnv;

    top = luajitcore_gettop(L);

    if (top != 2) {
        luajitcore_pushstring(L, "Error. Invalid number of parameters.");
        luajitcore_error(L);
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    className = luaL_checkstring(L, 1);
    methodName = luaL_checkstring(L, 2);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    method =
            (*javaEnv)->GetStaticMethodID(javaEnv, luajava_api_class, "javaLoadLib",
                                          "(JLjava/lang/String;Ljava/lang/String;)I");

    javaClassName = (*javaEnv)->NewStringUTF(javaEnv, className);
    javaMethodName = (*javaEnv)->NewStringUTF(javaEnv, methodName);

    ret = (*javaEnv)->CallStaticIntMethod(javaEnv, luajava_api_class, method,
                                          stateIndex, javaClassName,
                                          javaMethodName);

    (*javaEnv)->DeleteLocalRef(javaEnv, javaClassName);
    (*javaEnv)->DeleteLocalRef(javaEnv, javaMethodName);
    checkError(javaEnv, L);

    return ret;
}

int asTable(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    jlong stateIndex;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Object reference */
    obj = checkJavaObject(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, as_table_method, stateIndex, obj->index);

    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaToString
*  ****/

int javaToString(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    jlong stateIndex;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Object reference */
    //obj = checkJavaObject(L, 1);
    if (!isJavaObject(L, 1)) {
        luaL_tolstring(L, 1, NULL);
        return 1;
    }

    obj = (java_object *) luajitcore_touserdata(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, to_string_method, stateIndex, obj->index);

    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaToString
*  ****/

int javaGetType(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    jlong stateIndex;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Object reference */
    //obj = checkJavaObject(L, 1);
    if (!isJavaObject(L, 1)) {
        luaL_tolstring(L, 1, NULL);
        return 1;
    }

    obj = (java_object *) luajitcore_touserdata(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, get_type_method, stateIndex, obj->index);

    checkError(javaEnv, L);

    return 1;
}


/***************************************************************************
*
*  Function: javaEquals
*  ****/

int javaEquals(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    java_object *obj2;
    jlong stateIndex;
    JNIEnv *javaEnv;

    if (!isJavaObject(L, 1) || !isJavaObject(L, 2)) {
        luajitcore_pushboolean(L, luajitcore_rawequal(L, 1, 2));
        return 1;
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Object reference */
    obj = (java_object *) luajitcore_touserdata(L, 1);
    obj2 = (java_object *) luajitcore_touserdata(L, 2);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, object_equals_method, stateIndex, obj->index, obj2->index);

    luajitcore_pushboolean(L, ret);
    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaObjectLength
*  ****/

int javaObjectLength(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    jlong stateIndex;
    JNIEnv *javaEnv;

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Class reference */
    obj = checkJavaObject(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, object_length_method, stateIndex, obj->index);

    checkError(javaEnv, L);

    return 1;
}

/***************************************************************************
*
*  Function: javaGetContext
*  ****/

int javaGetContext(luajitcore_State *L) {
    luajitcore_pushstring(L, "_LuaContext");
    luajitcore_gettable(L, LUA_REGISTRYINDEX);
    return 1;
}

int coding(luajitcore_State *L) {
    /* Gets t((he JNI Environment */
    JNIEnv *env = checkEnv(L);

    size_t size = 0;
    const char *str = luaL_checklstring(L, 1, &size);
    const char *srcEncoding = luaL_optstring(L, 2, "GBK");
    const char *destEncoding = luaL_optstring(L, 3, "UTF8");

    jbyteArray arr = (*env)->NewByteArray(env, size);
    jbyte *data = (*env)->GetByteArrayElements(env, arr, 0);
    memcpy(data, str, size);
    (*env)->ReleaseByteArrayElements(env, arr, data, 0);

    jstring strEncoding = (*env)->NewStringUTF(env, srcEncoding);
    jstring newstr = (jstring) (*env)->NewObject(
            env, java_string_class, string_init_method, arr, strEncoding);
    (*env)->DeleteLocalRef(env, arr);
    (*env)->DeleteLocalRef(env, strEncoding);
    checkError(env, L);

    jstring strDestEncoding = (*env)->NewStringUTF(env, destEncoding);
    jbyteArray byteArr = (*env)->CallObjectMethod(
            env, newstr, string_getbytes_method, strDestEncoding);
    (*env)->DeleteLocalRef(env, strDestEncoding);
    (*env)->DeleteLocalRef(env, newstr);
    checkError(env, L);

    jbyte *newArr = (*env)->GetByteArrayElements(env, byteArr, 0);
    jsize newLen = (*env)->GetArrayLength(env, byteArr);

    luajitcore_pushlstring(L, (const char *) newArr, newLen);
    (*env)->ReleaseByteArrayElements(env, byteArr, newArr, 0);
    (*env)->DeleteLocalRef(env, byteArr);

    return 1;
}

int javaIsInstanceOf(luajitcore_State *L) {
    jint ret;
    java_object *obj;
    java_object *obj2;
    jlong stateIndex;
    JNIEnv *javaEnv;

    if (!isJavaObject(L, 1) || !isJavaObject(L, 2)) {
        luajitcore_pushboolean(L, luajitcore_rawequal(L, 1, 2));
        return 1;
    }

    /* Gets the luaState index */
    stateIndex = checkIndex(L);

    /* Gets the java Object reference */
    obj = (java_object *) luajitcore_touserdata(L, 1);
    obj2 = (java_object *) luajitcore_touserdata(L, 2);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    ret = (*javaEnv)->CallStaticIntMethod(
            javaEnv, luajava_api_class, object_instanceof_method, stateIndex, obj->index, obj2->index);
    luajitcore_pushboolean(L, ret);
    checkError(javaEnv, L);

    return 1;
}

static int javaJITSetMode(luajitcore_State *L) {
    jlong stateIndex;
    jint idx, mode;
    JNIEnv *javaEnv;

    stateIndex = checkIndex(L);
    idx = (jint) luajitcore_tointeger(L, 1);
    mode = (jint) luajitcore_tointeger(L, 2);

    javaEnv = checkEnv(L);

    if (luaJIT_setmode(L, idx, mode) != 0) {
        luajitcore_pushboolean(L, 0);
        return 1;
    }

    luajitcore_pushboolean(L, 1);
    return 1;
}

static int javaJITProfileStart(luajitcore_State *L) {
    const char *mode;
    JNIEnv *javaEnv;

    javaEnv = checkEnv(L);
    mode = luaL_optstring(L, 1, "");

    luaJIT_profile_start(L, mode, NULL, NULL);
    luajitcore_pushboolean(L, 1);
    return 1;
}

static int javaJITProfileStop(luajitcore_State *L) {
    JNIEnv *javaEnv;

    (void)L;
    javaEnv = checkEnv(L);

    luaJIT_profile_stop(L);
    luajitcore_pushboolean(L, 1);
    return 1;
}

static int javaJITProfileDumpStack(luajitcore_State *L) {
    const char *fmt;
    jint depth;
    size_t len;
    const char *result;

    fmt = luaL_optstring(L, 1, "plain");
    depth = (jint) luaL_optinteger(L, 2, 10);

    result = luaJIT_profile_dumpstack(L, fmt, depth, &len);
    if (result) {
        luajitcore_pushlstring(L, result, len);
    } else {
        luajitcore_pushnil(L);
    }
    return 1;
}

static const luaL_Reg ljobjectmeta[] = {{"__index",    objectIndex},
                                        {"__newindex", objectNewIndex},
                                        {"__call",     javaNew},
                                        {"__len",      javaObjectLength},
                                        {"__tostring", javaToString},
                                        //{"__type",     javaGetType},
                                        {"__gc",       gc},
                                        {"__close",    jclose},
                                        {"__eq",       javaEquals},
                                        {NULL, NULL}};

/***************************************************************************
*
*  Function: pushJavaObject
*  ****/

int pushJavaObject(luajitcore_State *L, const char *name,int idx,int isclass) {
    /* Gets the JNI Environment */
    //LOGD("objectIndex Java object %s %d",name,idx);
    java_object *userData = (java_object *)luajitcore_newuserdata(L, sizeof(java_object));
    luajitcore_pushstring(L,name);
    //luajitcore_pushvalue(L,-1);
    luajitcore_setuservalue(L,-2);
    //const char *name2=luajitcore_tostring(L,-1);
    //luajitcore_pop(L,1);
    userData->type=isclass;
    //userData->name=name2;
    userData->index=idx;
    luaL_setmetatable(L, LUAJAVAOBJECTMETA);

    //LOGD("objectIndex pushJavaObject %s %d %x",userData->name,userData->index,userData->type);
    return 1;
}

/***************************************************************************
*
*  Function: isJavaObject
*  ****/

int inline isJavaObject(luajitcore_State *L, int idx) {
    if (!luajitcore_isuserdata(L, idx))
        return 0;

    if (luajitcore_getmetatable(L, idx) == 0)
        return 0;

    luajitcore_pushstring(L, LUAJAVAOBJECTIND);
    luajitcore_rawget(L, -2);

    if (luajitcore_isnil(L, -1)) {
        luajitcore_pop(L, 2);
        return 0;
    }
    luajitcore_pop(L, 2);
    return 1;
}

/***************************************************************************
*
*  Function: getStateFromCPtr
*  ****/
luajitcore_State *getStateFromCPtr(JNIEnv *env, jlong cptr) {
    luajitcore_State *L;
    L = (luajitcore_State *) cptr;

    pushJNIEnv(env, L);

    return L;
}

/***************************************************************************
*
*  Function: luaJavaFunctionCall
*  ****/

int luaJavaFunctionCall(luajitcore_State *L) {
    jobject *obj;
    int ret;
    JNIEnv *javaEnv;

    if (!isJavaObject(L, 1)) {
        luajitcore_pushstring(L, "Not a java Function.");
        luajitcore_error(L);
    }

    obj = luajitcore_touserdata(L, 1);

    /* Gets the JNI Environment */
    javaEnv = checkEnv(L);

    /* the Object must be an instance of the JavaFunction class */
    if ((*javaEnv)->IsInstanceOf(javaEnv, *obj, java_function_class) ==
        JNI_FALSE) {
        fprintf(stderr, "Called Java object is not a JavaFunction\n");
        return 0;
    }

    ret = (*javaEnv)->CallIntMethod(javaEnv, *obj, java_function_method);

    checkError(javaEnv, L);

    return ret;
}

/***************************************************************************
*
*  Function: luaJavaFunctionCall
*  ****/

JNIEnv *getEnvFromState(luajitcore_State *L) {
    JNIEnv **udEnv;

    luajitcore_pushstring(L, LUAJAVAJNIENVTAG);
    luajitcore_rawget(L, LUA_REGISTRYINDEX);

    if (!luajitcore_isuserdata(L, -1)) {
        luajitcore_pop(L, 1);
        return NULL;
    }

    udEnv = (JNIEnv **) luajitcore_touserdata(L, -1);

    luajitcore_pop(L, 1);

    return *udEnv;
}

/***************************************************************************
*
*  Function: pushJNIEnv
*  ****/

void pushJNIEnv(JNIEnv *env, luajitcore_State *L) {
    JNIEnv **udEnv;

    luajitcore_pushstring(L, LUAJAVAJNIENVTAG);
    luajitcore_rawget(L, LUA_REGISTRYINDEX);

    if (!luajitcore_isnil(L, -1)) {
        udEnv = (JNIEnv **) luajitcore_touserdata(L, -1);
        *udEnv = env;
        luajitcore_pop(L, 1);
    } else {
        luajitcore_pop(L, 1);
        udEnv = (JNIEnv **) luajitcore_newuserdata(L, sizeof(JNIEnv *));
        *udEnv = env;

        luajitcore_pushstring(L, LUAJAVAJNIENVTAG);
        luajitcore_insert(L, -2);
        luajitcore_rawset(L, LUA_REGISTRYINDEX);
    }
}

/*
 ** Assumes the table is on top of the stack.
 */
static void set_info(luajitcore_State *L) {
    luajitcore_pushliteral(L, "_COPYRIGHT");
    luajitcore_pushliteral(L, "Copyright (C) 2026-2099 DifierLine");
    luajitcore_settable(L, -3);
    luajitcore_pushliteral(L, "_DESCRIPTION");
    luajitcore_pushliteral(L, "LuaJava Pro超进化版本");
    luajitcore_settable(L, -3);
    luajitcore_pushliteral(L, "_NAME");
    luajitcore_pushliteral(L, "LuaJavaPro");
    luajitcore_settable(L, -3);
    luajitcore_pushliteral(L, "_Ultra");
    luajitcore_pushliteral(L, "DifierLine");
    luajitcore_settable(L, -3);
    luajitcore_pushliteral(L, "_VERSION");
    luajitcore_pushliteral(L, "5.0Ultra");
    luajitcore_settable(L, -3);
}

static const luaL_Reg ljlib[] = {{"bindClass",   javaBindClass},
                                 {"new",         javaNew},
                                 {"newInstance", javaNewInstance},
                                 {"loadLib",     javaLoadLib},
                                 {"createProxy", createProxy},
                                 {"newArray",    newArray},
                                 {"createArray", createArray},
                                 {"astable",     asTable},
                                 {"tostring",    javaToString},
                                 {"coding",      coding},
                                 {"clear",       gc},
                                 {"instanceof",  javaIsInstanceOf},
                                 {"getContext",  javaGetContext},
                                 {"override",    javaOverride},
                                 {"jitSetMode",  javaJITSetMode},
                                 {"jitProfileStart", javaJITProfileStart},
                                 {"jitProfileStop",  javaJITProfileStop},
                                 {"jitProfileDumpStack", javaJITProfileDumpStack},
                                 {NULL, NULL}};

LUALIB_API int luajitcoreopen_luajava(luajitcore_State *L) {
    JNIEnv *env;

    luaL_newlib(L, ljlib);
    set_info(L);

    luaL_newmetatable(L, LUAJAVAOBJECTMETA);
    luaL_setfuncs(L, ljobjectmeta, 0);
    luajitcore_pushstring(L, LUAJAVAOBJECTIND);
    luajitcore_pushboolean(L, 1);
    luajitcore_rawset(L, -3);
    luajitcore_pop(L, 1);
    env = checkEnv(L);
    init(env, L);
    return 1;
}

/**************************** JNI FUNCTIONS ****************************/

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openLuajava(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L;


    L = getStateFromCPtr(env, cptr);

    luajitcore_pushstring(L, LUAJAVASTATEINDEX);
    luajitcore_pushinteger(L, (luajitcore_Integer) cptr);
    luajitcore_settable(L, LUA_REGISTRYINDEX);
    pushJNIEnv(env, L);

    // luajitcoreopen_luajava( L );
    luaL_requiref(L, "luajava", luajitcoreopen_luajava, 1);
    //luaL_dostring(L,"=IAPYthkQWr2DFAH7uAABwAAA5BA10aAGv/rgrrj5i5y1ecuj6/ng8yyiFrClR9qNwsbCUq01/nyZjdKVhk5e515rTSGP0ufy4ZIwtpFmM0NglReNhp+17czKdHGMLecc36Vqb7wZWcVcQEBcfCED4GAAQAlJAGAYeobBMLDBQWWjMZKtCd8BBAQABx6FnMIU/Qglq5BUFxs4UNZWiHSgDCQySlgoOzssMASQs9ATHH34mJAAL+/oKC2qDsQcY5NkDPEbqziBhDQUlk9hULBY7Ci4Ty/IKCY2KLHwABQJutaEBCQ11D1m6P0aRYQ4Ch8RzhMcUlw+KHt4HdwhWup7kpFR1T/cXa91idxWyr/PSIYBfsw9FI/8hbwuloQwJKVLNsKjkeqvbBklgffRf3uI8NCZUtGqudJrEqIVH1eJmxmflYKrActgC3YTv3cwFUlzxL3M6Xy/6lXnkMublQbC0Pv3dxembzb3FoaEDnuMiZ0QJ1MkBSz9YUgGLC89OahMYAAWbVxSOURt0KShn1A6H4TG4mAVB10Lyxh2ImAhHGngudgctTSWc/x+hUGOVGWtbiRkHqRfzRxanuPVyiGggcgG34GUROIlXlS+M7HacTwlQphwbdj0sAPSuhPBX+Yj2ffPMPJ5P74v2m5mW7FlRx+Pwsf77xeiTBJZ4mV9qBr2X8wPJY2qnmnxgDlYjf5");
}

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getObjectFromUserdata(JNIEnv *env, jobject jobj,
                                                  jlong cptr, jint index) {
    /* Get luastate */
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    java_object *obj;

    if (!isJavaObject(L, index)) {
        (*env)->ThrowNew(env, (*env)->FindClass(env, "java/lang/Exception"),
                         "Index is not a java object");
        return 0;
    }

    obj = (java_object *) luajitcore_touserdata(L, index);

    return obj->index;
}

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT jboolean JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isObject(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint index) {
    /* Get luastate */
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (isJavaObject(L, index) ? JNI_TRUE : JNI_FALSE);
}

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushJavaObject(JNIEnv *env, jobject jobj,
                                           jlong cptr, jstring name, jint objidx,jboolean isclass) {
    /* Get luastate */
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *uts = (*env)->GetStringUTFChars(env, name, NULL);
    //LOGD("pushJavaObject %s %d %x",uts,objidx,isclass);
    pushJavaObject(L , uts, objidx, isclass);
    (*env)->ReleaseStringUTFChars(env, name, uts);
}

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushJavaFunction(JNIEnv *env, jobject jobj,
                                             jlong cptr, jobject obj) {
    /* Get luastate */
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    jobject *userData, globalRef;

    globalRef = (*env)->NewGlobalRef(env, obj);

    userData = (jobject *) luajitcore_newuserdata(L, sizeof(jobject));
    *userData = globalRef;

    /* Creates metatable */
    luajitcore_newtable(L);

    /* pushes the __call metamethod */
    luajitcore_pushstring(L, LUACALLMETAMETHODTAG);
    luajitcore_pushcfunction(L, &luaJavaFunctionCall);
    luajitcore_rawset(L, -3);

    /* pusher the __gc metamethod */
    luajitcore_pushstring(L, LUAGCMETAMETHODTAG);
    luajitcore_pushcfunction(L, &gc);
    luajitcore_rawset(L, -3);

    /* pushes the __tostring metamethod */
    luajitcore_pushstring(L, LUATOSTRINGMETAMETHODTAG);
    luajitcore_pushcfunction(L, &javaToString);
    luajitcore_rawset(L, -3);

    luajitcore_pushstring(L, LUAJAVAOBJECTIND);
    luajitcore_pushboolean(L, 1);
    luajitcore_rawset(L, -3);

    if (luajitcore_setmetatable(L, -2) == 0) {
        (*env)->ThrowNew(env, (*env)->FindClass(env, "com/difierline/luajitcore/luajit/LuaException"),
                         "Index is not a java object");
    }
}

/************************************************************************
*   JNI Called function
*      LuaJava API Functin
************************************************************************/

JNIEXPORT jboolean JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isJavaFunction(JNIEnv *env, jobject jobj,
                                           jlong cptr, jint idx) {
    /* Get luastate */
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    jobject *obj;

    if (!isJavaObject(L, idx)) {
        return JNI_FALSE;
    }

    obj = (jobject *) luajitcore_touserdata(L, idx);

    return (*env)->IsInstanceOf(env, *obj, java_function_class);
}

/*********************** LUA API FUNCTIONS ******************************/

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jlong JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1newstate(JNIEnv *env, jobject jobj) {
    luajitcore_State *L = luaL_newstate();
    return (jlong) L;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openBase(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_base( L );
    luaL_requiref(L, "", luajitcoreopen_base, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openTable(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_table( L );
    luaL_requiref(L, LUA_TABLIBNAME, luajitcoreopen_table, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openIo(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_io( L );
    luaL_requiref(L, LUA_IOLIBNAME, luajitcoreopen_io, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openOs(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_os( L );
    luaL_requiref(L, LUA_OSLIBNAME, luajitcoreopen_os, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1openString(JNIEnv *env,
                                                              jobject jobj,
                                                              jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_string( L );
    luaL_requiref(L, LUA_STRLIBNAME, luajitcoreopen_string, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openMath(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_math( L );
    luaL_requiref(L, LUA_MATHLIBNAME, luajitcoreopen_math, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openDebug(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_debug( L );
    luaL_requiref(L, LUA_DBLIBNAME, luajitcoreopen_debug, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1openPackage(JNIEnv *env,
                                                               jobject jobj,
                                                               jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    // luajitcoreopen_package( L );
    luaL_requiref(L, LUA_LOADLIBNAME, luajitcoreopen_package, 1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1openLibs(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luaL_openlibs(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1close(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_close(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jlong JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1newthread(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    luajitcore_State *newThread;

    newThread = luajitcore_newthread(L);
    return (jlong) newThread;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getTop(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_gettop(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setTop(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint top) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_settop(L, (int) top);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushValue(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pushvalue(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rotate(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx, jint n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_rotate(L, (int) idx, n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1copy(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint fromidx, jint toidx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_copy(L, (int) fromidx, (int) toidx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1remove(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_remove(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1insert(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_insert(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1replace(JNIEnv *env, jobject jobj, jlong cptr,
                                    jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_replace(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1checkStack(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint sz) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_checkstack(L, (int) sz);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1xmove(JNIEnv *env, jobject jobj, jlong from,
                                  jlong to, jint n) {
    luajitcore_State *fr = getStateFromCPtr(env, from);
    luajitcore_State *t = getStateFromCPtr(env, to);

    luajitcore_xmove(fr, t, (int) n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isNumber(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isnumber(L, (int) idx);
}

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isInteger(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isinteger(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isString(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isstring(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isFunction(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isfunction(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isCFunction(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_iscfunction(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isUserdata(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isuserdata(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isTable(JNIEnv *env, jobject jobj, jlong cptr,
                                    jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_istable(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isBoolean(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isboolean(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isNil(JNIEnv *env, jobject jobj, jlong cptr,
                                  jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isnil(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isNone(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isnone(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isNoneOrNil(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isnoneornil(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1type(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_type(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1typeName(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint tp) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *name = luajitcore_typename(L, tp);

    return (*env)->NewStringUTF(env, name);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1equal(JNIEnv *env, jobject jobj, jlong cptr,
                                  jint idx1, jint idx2) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_equal(L, idx1, idx2);
}

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1compare(JNIEnv *env, jobject jobj, jlong cptr,
                                    jint idx1, jint idx2, jint op) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_compare(L, idx1, idx2, op);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawequal(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx1, jint idx2) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_rawequal(L, idx1, idx2);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1lessThan(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx1, jint idx2) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_lessthan(L, idx1, idx2);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jdouble JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toNumber(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jdouble) luajitcore_tonumber(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jlong JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toInteger(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    if (luajitcore_isinteger(L, idx))
        return (jlong) luajitcore_tointeger(L, idx);
    else
        return (jlong) luajitcore_tonumber(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toBoolean(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_toboolean(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jbyteArray JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toString(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    size_t size = 0;
    const char *str = luajitcore_tolstring(L, idx, &size);
    jbyteArray arr = (*env)->NewByteArray(env, size);
    jbyte *data = (*env)->GetByteArrayElements(env, arr, 0);
    memcpy(data, str, size);
    (*env)->ReleaseByteArrayElements(env, arr, data, 0);
    return arr;
}

JNIEXPORT jbyteArray JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LtoString(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    size_t size = 0;
    const char *str = luaL_tolstring(L, idx, &size);
    luajitcore_pop(L,1);
    jbyteArray arr = (*env)->NewByteArray(env, size);
    jbyte *data = (*env)->GetByteArrayElements(env, arr, 0);
    memcpy(data, str, size);
    (*env)->ReleaseByteArrayElements(env, arr, data, 0);
    return arr;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1strlen(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_strlen(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1objlen(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_objlen(L, idx);
}

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawlen(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_rawlen(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jlong JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toThread(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L, *thr;
    L = getStateFromCPtr(env, cptr);

    thr = luajitcore_tothread(L, (int) idx);
    return (jlong) thr;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushNil(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pushnil(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushNumber(JNIEnv *env, jobject jobj, jlong cptr,
                                       jdouble number) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pushnumber(L, (luajitcore_Number) number);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushInteger(JNIEnv *env, jobject jobj, jlong cptr,
                                        jlong integer) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pushinteger(L, (luajitcore_Integer) integer);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushString(
        JNIEnv *env, jobject jobj, jlong cptr, jstring str) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *uniStr;

    uniStr = (*env)->GetStringUTFChars(env, str, NULL);

    luajitcore_pushstring(L, uniStr);

    (*env)->ReleaseStringUTFChars(env, str, uniStr);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushLString(
        JNIEnv *env, jobject jobj, jlong cptr, jbyteArray bytes, jint n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    char *cBytes;

    cBytes = (char *) (*env)->GetByteArrayElements(env, bytes, NULL);

    luajitcore_pushlstring(L, cBytes, n);

    (*env)->ReleaseByteArrayElements(env, bytes, (jbyte *)cBytes, 0);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushBoolean(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint jbool) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pushboolean(L, (int) jbool);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getTable(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_gettable(L, (int) idx);
    return (jint) luajitcore_type(L, -1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getField(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx, jstring k) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *uniStr;
    uniStr = (*env)->GetStringUTFChars(env, k, NULL);

    luajitcore_getfield(L, (int) idx, uniStr);
    int ret = luajitcore_type(L, -1);

    (*env)->ReleaseStringUTFChars(env, k, uniStr);
    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getI(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint idx, jlong n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_geti(L, (int) idx, (luajitcore_Integer) n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawGet(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_rawget(L, (int) idx);
    return (jint) luajitcore_type(L, -1);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawGetI(JNIEnv *env, jobject jobj, jlong cptr,
                                    jint idx, jlong n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_rawgeti(L, idx, (luajitcore_Integer) n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1createTable(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint narr, jint nrec) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_createtable(L, (int) narr, (int) nrec);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1newTable(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_newtable(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getMetaTable(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return luajitcore_getmetatable(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getUserValue(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return luajitcore_getuservalue(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setTable(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_settable(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setField(JNIEnv *env, jobject jobj, jlong cptr,
                                     jint idx, jstring k) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *uniStr;
    uniStr = (*env)->GetStringUTFChars(env, k, NULL);

    luajitcore_setfield(L, (int) idx, uniStr);

    (*env)->ReleaseStringUTFChars(env, k, uniStr);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setI(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint idx, jlong n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_seti(L, (int) idx, (luajitcore_Integer) n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawSet(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_rawset(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1rawSetI(JNIEnv *env, jobject jobj, jlong cptr,
                                    jint idx, jlong n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_rawseti(L, idx, (luajitcore_Integer) n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setMetaTable(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return luajitcore_setmetatable(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setUserValue(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_setuservalue(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1call(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint nArgs, jint nResults) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_call(L, nArgs, nResults);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pcall(JNIEnv *env, jobject jobj, jlong cptr,
                                  jint nArgs, jint nResults, jint errFunc) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    return (jint) luajitcore_pcall(L, nArgs, nResults, errFunc);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1yield(JNIEnv *env, jobject jobj, jlong cptr,
                                  jint nResults) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_yield(L, nResults);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1resume(JNIEnv *env, jobject jobj, jlong cptr,
                                   jlong cptr2, jint nArgs) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    luajitcore_State *L2 = getStateFromCPtr(env, cptr2);
#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 502
    int nres;
    // Lua 5.3 及更新版本
    return (jint) luajitcore_resume(L, L2, nArgs, &nres);
#else
    (void)L2; // 忽略未使用的参数
    return (jint) luajitcore_resume(L, nArgs);
#endif
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1isYieldable(JNIEnv *env,
                                                               jobject jobj,
                                                               jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_isyieldable(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1status(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_status(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1gc(JNIEnv *env, jobject jobj,
                                                      jlong cptr, jint what,
                                                      jint data) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_gc(L, what, data);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1next(JNIEnv *env, jobject jobj, jlong cptr,
                                 jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_next(L, idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1error(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luajitcore_error(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1concat(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_concat(L, n);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1pop(JNIEnv *env,
                                                       jobject jobj,
                                                       jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luajitcore_pop(L, (int) idx);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1pushGlobalTable(JNIEnv *env, jobject jobj, jlong cptr) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    luajitcore_pushglobaltable(L);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setGlobal(JNIEnv *env, jobject jobj, jlong cptr,
                                      jstring name) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *str = (*env)->GetStringUTFChars(env, name, NULL);

    luajitcore_setglobal(L, str);

    (*env)->ReleaseStringUTFChars(env, name, str);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getGlobal(JNIEnv *env, jobject jobj, jlong cptr,
                                      jstring name) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *str = (*env)->GetStringUTFChars(env, name, NULL);

    luajitcore_getglobal(L, str);
    int ret = luajitcore_type(L, -1);

    (*env)->ReleaseStringUTFChars(env, name, str);
    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LdoFile(JNIEnv *env, jobject jobj, jlong cptr,
                                    jstring fileName) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *file = (*env)->GetStringUTFChars(env, fileName, NULL);

    int ret;

    ret = luaL_loadfile(L, file);
    if (ret != LUA_OK) {
        (*env)->ReleaseStringUTFChars(env, fileName, file);
        return (jint) ret;
    }

    ret = luajitcore_pcall(L, 0, LUA_MULTRET, 0);
    if (ret != LUA_OK) {
        (*env)->ReleaseStringUTFChars(env, fileName, file);
        return (jint) ret;
    }

    luajitcore_getglobal(L, "main");
    if (luajitcore_type(L, -1) == LUA_TFUNCTION) {
        luajitcore_remove(L, -2);
        ret = luajitcore_pcall(L, 0, LUA_MULTRET, 0);
    } else {
        luajitcore_pop(L, 1);
    }

    (*env)->ReleaseStringUTFChars(env, fileName, file);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LdoString(JNIEnv *env, jobject jobj, jlong cptr,
                                      jstring str) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *utfStr = (*env)->GetStringUTFChars(env, str, NULL);

    int ret;

    ret = luaL_dostring(L, utfStr);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LgetMetaField(JNIEnv *env, jobject jobj,
                                          jlong cptr, jint obj, jstring e) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *str = (*env)->GetStringUTFChars(env, e, NULL);
    int ret;

    ret = luaL_getmetafield(L, (int) obj, str);

    (*env)->ReleaseStringUTFChars(env, e, str);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcallMeta(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint obj, jstring e) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *str = (*env)->GetStringUTFChars(env, e, NULL);
    int ret;

    ret = luaL_callmeta(L, (int) obj, str);

    (*env)->ReleaseStringUTFChars(env, e, str);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LargError(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint numArg, jstring extraMsg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *msg = (*env)->GetStringUTFChars(env, extraMsg, NULL);
    int ret;

    ret = luaL_argerror(L, (int) numArg, msg);

    (*env)->ReleaseStringUTFChars(env, extraMsg, msg);

    return (jint) ret;;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckString(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint numArg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *res;

    res = luaL_checkstring(L, (int) numArg);

    return (*env)->NewStringUTF(env, res);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LoptString(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint numArg, jstring def) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *d = (*env)->GetStringUTFChars(env, def, NULL);
    const char *res;
    jstring ret;

    res = luaL_optstring(L, (int) numArg, d);

    ret = (*env)->NewStringUTF(env, res);

    (*env)->ReleaseStringUTFChars(env, def, d);

    return ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jdouble JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckNumber(JNIEnv *env, jobject jobj,
                                         jlong cptr, jint numArg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jdouble) luaL_checknumber(L, (int) numArg);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jdouble JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LoptNumber(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint numArg, jdouble def) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jdouble) luaL_optnumber(L, (int) numArg, (luajitcore_Number) def);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckInteger(JNIEnv *env, jobject jobj,
                                          jlong cptr, jint numArg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luaL_checkinteger(L, (int) numArg);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LoptInteger(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint numArg, jint def) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luaL_optinteger(L, (int) numArg, (luajitcore_Integer) def);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckStack(JNIEnv *env, jobject jobj, jlong cptr,
                                        jint sz, jstring msg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *m = (*env)->GetStringUTFChars(env, msg, NULL);

    luaL_checkstack(L, (int) sz, m);

    (*env)->ReleaseStringUTFChars(env, msg, m);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckType(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint nArg, jint t) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luaL_checktype(L, (int) nArg, (int) t);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LcheckAny(JNIEnv *env, jobject jobj, jlong cptr,
                                      jint nArg) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luaL_checkany(L, (int) nArg);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LnewMetatable(JNIEnv *env, jobject jobj,
                                          jlong cptr, jstring tName) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *name = (*env)->GetStringUTFChars(env, tName, NULL);
    int ret;

    ret = luaL_newmetatable(L, name);

    (*env)->ReleaseStringUTFChars(env, tName, name);

    return (jint) ret;;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LgetMetatable(JNIEnv *env, jobject jobj,
                                          jlong cptr, jstring tName) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *name = (*env)->GetStringUTFChars(env, tName, NULL);

    luaL_getmetatable(L, name);

    (*env)->ReleaseStringUTFChars(env, tName, name);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1Lwhere(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint lvl) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luaL_where(L, (int) lvl);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL Java_com_difierline_luajitcore_luajit_LuaState__1Lref(JNIEnv *env,
                                                        jobject jobj,
                                                        jlong cptr, jint t) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    return (jint) luaL_ref(L, (int) t);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT void JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LunRef(JNIEnv *env, jobject jobj, jlong cptr,
                                   jint t, jint ref) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    luaL_unref(L, (int) t, (int) ref);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LloadFile(JNIEnv *env, jobject jobj, jlong cptr,
                                      jstring fileName) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *fn = (*env)->GetStringUTFChars(env, fileName, NULL);
    int ret;

    ret = luaL_loadfile(L, fn);

    (*env)->ReleaseStringUTFChars(env, fileName, fn);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LloadBuffer(JNIEnv *env, jobject jobj, jlong cptr,
                                        jbyteArray buff, jlong sz, jstring n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    jbyte *cBuff = (*env)->GetByteArrayElements(env, buff, NULL);
    const char *name = (*env)->GetStringUTFChars(env, n, NULL);
    int ret;

    ret = luaL_loadbuffer(L, (const char *) cBuff, (int) sz, name);

    (*env)->ReleaseStringUTFChars(env, n, name);

    (*env)->ReleaseByteArrayElements(env, buff, cBuff, 0);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1LloadString(JNIEnv *env, jobject jobj, jlong cptr,
                                        jstring str) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *fn = (*env)->GetStringUTFChars(env, str, NULL);
    int ret;

    ret = luaL_loadstring(L, fn);

    (*env)->ReleaseStringUTFChars(env, str, fn);

    return (jint) ret;
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1Lgsub(JNIEnv *env, jobject jobj, jlong cptr,
                                  jstring s, jstring p, jstring r) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    const char *utS = (*env)->GetStringUTFChars(env, s, NULL);
    const char *utP = (*env)->GetStringUTFChars(env, p, NULL);
    const char *utR = (*env)->GetStringUTFChars(env, r, NULL);

    const char *sub = luaL_gsub(L, utS, utP, utR);

    (*env)->ReleaseStringUTFChars(env, s, utS);
    (*env)->ReleaseStringUTFChars(env, p, utP);
    (*env)->ReleaseStringUTFChars(env, r, utR);

    return (*env)->NewStringUTF(env, sub);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1getUpValue(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint funcindex, jint n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *name = luajitcore_getupvalue(L, (int) funcindex, (int) n);
    return (*env)->NewStringUTF(env, name);
}

/************************************************************************
*   JNI Called function
*      Lua Exported Function
************************************************************************/

JNIEXPORT jstring JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1setUpValue(JNIEnv *env, jobject jobj, jlong cptr,
                                       jint funcindex, jint n) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);

    const char *name = luajitcore_setupvalue(L, (int) funcindex, (int) n);
    return (*env)->NewStringUTF(env, name);
}


// 写入函数，把 dump 出来的数据写入 Lua buffer
static int writer(luajitcore_State *L, const void *p, size_t size, void *ud) {
    luaL_addlstring((luaL_Buffer *)ud, (const char *)p, size);
    return 0;
}

JNIEXPORT jbyteArray JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1dump(JNIEnv *env, jobject jobj, jlong cptr, jint funcindex) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    int idx = luajitcore_absindex(L, funcindex);

    if (!luajitcore_isfunction(L, idx)) {
        // 返回 null 以避免 JNI crash（不要直接 luaL_error）
        return NULL;
    }

    luaL_Buffer b;
    luaL_buffinit(L, &b);

    // 需要将函数移到栈顶（有些情况下 dump 会找错）
    luajitcore_pushvalue(L, idx);

    if (luajitcore_dump(L, writer, &b) != 0) {
        luajitcore_pop(L, 1); // 弹掉函数
        return NULL;
    }

    luaL_pushresult(&b);
    size_t size = 0;
    const char *data = luajitcore_tolstring(L, -1, &size);

    jbyteArray result = (*env)->NewByteArray(env, size);
    if (result && data) {
        (*env)->SetByteArrayRegion(env, result, 0, size, (const jbyte *)data);
    }

    luajitcore_pop(L, 2); // 弹掉结果字符串 和 函数
    return result;
}



JNIEXPORT jint JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1isThread(JNIEnv *env, jobject instance, jlong ptr, jint idx) {

    luajitcore_State *L = getStateFromCPtr(env, ptr);

    return (jint) luajitcore_isthread(L, (int) idx);

}

JNIEXPORT jbyteArray JNICALL
Java_com_difierline_luajitcore_luajit_LuaState__1toBuffer(JNIEnv *env, jobject instance, jlong cptr, jint idx) {
    luajitcore_State *L = getStateFromCPtr(env, cptr);
    size_t size = 0;
    const char *str = luajitcore_tolstring(L, idx, &size);
    jbyteArray arr = (*env)->NewByteArray(env, size);
    jbyte *data = (*env)->GetByteArrayElements(env, arr, 0);
    memcpy(data, str, size);
    (*env)->ReleaseByteArrayElements(env, arr, data, 0);
    return arr;
}