/*
** $Id: ltable.h $
** Lua tables (hash)
** See Copyright Notice in lua.h
*/

#ifndef ltable_h
#define ltable_h

#include "lobject.h"


#define gnode(t,i)	(&(t)->node[i])
#define gval(n)		(&(n)->i_val)
#define gnext(n)	((n)->u.next)


/*
** Clear all bits of fast-access metamethods, which means that the table
** may have any of these metamethods. (First access that fails after the
** clearing will set the bit again.)
*/
#define invalidateTMcache(t)	((t)->flags &= cast_byte(~maskflags))

/*
** Bit BITDUMMY set in 'flags' means the table is using the dummy node
** for its hash part.
*/

#define BITDUMMY		(1 << 6)
#define NOTBITDUMMY		cast_byte(~BITDUMMY)
#define isdummy(t)		((t)->lastfree == NULL)

#define setnodummy(t)		((t)->flags &= NOTBITDUMMY)
#define setdummy(t)		((t)->flags |= BITDUMMY)


/* allocated size for hash nodes */
#define allocsizenode(t)	(isdummy(t) ? 0 : sizenode(t))


/* returns the Node, given the value of a table entry */
#define nodefromval(v)	cast(Node *, (v))


/**
 * @brief Gets an integer key from a table.
 *
 * @param t The table.
 * @param key The integer key.
 * @return The value associated with the key.
 */
LUAI_FUNC const TValue *luaH_getint (Table *t, lua_Integer key);


#define luaH_fastgeti(t,k,res,tag) \
  { Table *h = t; lua_Unsigned u = l_castS2U(k) - 1u; \
    if ((u < h->asize)) { \
      tag = *getArrTag(h, u); \
      if (!tagisempty(tag)) { farr2val(h, u, tag, res); }} \
    else { tag = luaH_getint(h, (k), res); }}


#define luaH_fastseti(t,k,val,hres) \
  { Table *h = t; lua_Unsigned u = l_castS2U(k) - 1u; \
    if ((u < h->asize)) { \
      lu_byte *tag = getArrTag(h, u); \
      if (checknoTM(h->metatable, TM_NEWINDEX) || !tagisempty(*tag)) \
        { fval2arr(h, u, tag, val); hres = HOK; } \
      else hres = ~cast_int(u); } \
    else { hres = luaH_psetint(h, k, val); }}


/* results from pset */
#define HOK		0
#define HNOTFOUND	1
#define HNOTATABLE	2
#define HFIRSTNODE	3

/*
** 'luaH_get*' operations set 'res', unless the value is absent, and
** return the tag of the result.
** The 'luaH_pset*' (pre-set) operations set the given value and return
** HOK, unless the original value is absent. In that case, if the key
** is really absent, they return HNOTFOUND. Otherwise, if there is a
** slot with that key but with no value, 'luaH_pset*' return an encoding
** of where the key is (usually called 'hres'). (pset cannot set that
** value because there might be a metamethod.) If the slot is in the
** hash part, the encoding is (HFIRSTNODE + hash index); if the slot is
** in the array part, the encoding is (~array index), a negative value.
** The value HNOTATABLE is used by the fast macros to signal that the
** value being indexed is not a table.
** (The size for the array part is limited by the maximum power of two
** that fits in an unsigned integer; that is INT_MAX+1. So, the C-index
** ranges from 0, which encodes to -1, to INT_MAX, which encodes to
** INT_MIN. The size of the hash part is limited by the maximum power of
** two that fits in a signed integer; that is (INT_MAX+1)/2. So, it is
** safe to add HFIRSTNODE to any index there.)
*/


/*
** The array part of a table is represented by an inverted array of
** values followed by an array of tags, to avoid wasting space with
** padding. In between them there is an unsigned int, explained later.
** The 'array' pointer points between the two arrays, so that values are
** indexed with negative indices and tags with non-negative indices.

             Values                              Tags
  --------------------------------------------------------
  ...  |   Value 1     |   Value 0     |unsigned|0|1|...
  --------------------------------------------------------
                                       ^ t->array

** All accesses to 't->array' should be through the macros 'getArrTag'
** and 'getArrVal'.
*/

/* Computes the address of the tag for the abstract C-index 'k' */
#define getArrTag(t,k)	(cast(lu_byte*, (t)->array) + sizeof(unsigned) + (k))

/* Computes the address of the value for the abstract C-index 'k' */
#define getArrVal(t,k)	((t)->array - 1 - (k))


/*
** The unsigned between the two arrays is used as a hint for #t;
** see luaH_getn. It is stored there to avoid wasting space in
** the structure Table for tables with no array part.
*/
#define lenhint(t)	cast(unsigned*, (t)->array)


/*
** Move TValues to/from arrays, using C indices
*/
#define arr2obj(h,k,val)  \
  ((val)->tt_ = *getArrTag(h,(k)), (val)->value_ = *getArrVal(h,(k)))

#define obj2arr(h,k,val)  \
  (*getArrTag(h,(k)) = (val)->tt_, (*getArrVal(h,(k))).value_ = (val)->value_)


/*
** Often, we need to check the tag of a value before moving it. The
** following macros also move TValues to/from arrays, but receive the
** precomputed tag value or address as an extra argument.
*/
#define farr2val(h,k,tag,res)  \
  do { (res)->tt_ = tag; (res)->value_ = getArrVal(h,(k))->value_; } while(0)

#define fval2arr(h,k,tag,val)  \
  do { *tag = (val)->tt_; getArrVal(h,(k))->value_ = (val)->value_; } while(0)


/**
 * @brief Sets an integer key in a table.
 *
 * @param L The Lua state.
 * @param t The table.
 * @param key The integer key.
 * @param value The value to set.
 */
LUAI_FUNC void luaH_setint (lua_State *L, Table *t, lua_Integer key,
                                                    TValue *value);

/**
 * @brief Gets a short string key from a table.
 *
 * @param t The table.
 * @param key The short string key.
 * @return The value associated with the key.
 */
LUAI_FUNC const TValue *luaH_getshortstr (Table *t, TString *key);

/**
 * @brief Gets a string key from a table.
 *
 * @param t The table.
 * @param key The string key.
 * @return The value associated with the key.
 */
LUAI_FUNC const TValue *luaH_getstr (Table *t, TString *key);

/**
 * @brief Gets a generic key from a table.
 *
 * @param t The table.
 * @param key The key.
 * @return The value associated with the key.
 */
LUAI_FUNC const TValue *luaH_get (Table *t, const TValue *key);

/**
 * @brief Optimized get function for tables.
 *
 * @param t The table.
 * @param key The key.
 * @return The value associated with the key.
 */
LUAI_FUNC const TValue *luaH_get_optimized (Table *t, const TValue *key);

/**
 * @brief Sets a generic key in a table.
 *
 * @param L The Lua state.
 * @param t The table.
 * @param key The key.
 * @param value The value to set.
 */
LUAI_FUNC void luaH_set (lua_State *L, Table *t, const TValue *key,
                                                 TValue *value);

/**
 * @brief Finishes a set operation (used when the key is not present).
 *
 * @param L The Lua state.
 * @param t The table.
 * @param key The key.
 * @param slot The slot where the key should be inserted.
 * @param value The value to set.
 */
LUAI_FUNC void luaH_finishset (lua_State *L, Table *t, const TValue *key,
                                       const TValue *slot, TValue *value);

/**
 * @brief Creates a new table.
 *
 * @param L The Lua state.
 * @return The new table.
 */
LUAI_FUNC Table *luaH_new (lua_State *L);

/**
 * @brief Resizes a table.
 *
 * @param L The Lua state.
 * @param t The table.
 * @param nasize New array size.
 * @param nhsize New hash size.
 */
LUAI_FUNC void luaH_resize (lua_State *L, Table *t, unsigned int nasize,
                                                    unsigned int nhsize);

/**
 * @brief Resizes the array part of a table.
 *
 * @param L The Lua state.
 * @param t The table.
 * @param nasize New array size.
 */
LUAI_FUNC void luaH_resizearray (lua_State *L, Table *t, unsigned int nasize);

/**
 * @brief Frees a table.
 *
 * @param L The Lua state.
 * @param t The table.
 */
LUAI_FUNC void luaH_free (lua_State *L, Table *t);

/**
 * @brief Iterates over a table.
 *
 * @param L The Lua state.
 * @param t The table.
 * @param key The current key (on stack).
 * @return 1 if there are more elements, 0 otherwise.
 */
LUAI_FUNC int luaH_next (lua_State *L, Table *t, StkId key);

/**
 * @brief Returns the "length" of a table (the # operator).
 *
 * @param t The table.
 * @return The length.
 */
LUAI_FUNC lua_Unsigned luaH_getn (Table *t);

/**
 * @brief Returns the real size of the array part of a table.
 *
 * @param t The table.
 * @return The real array size.
 */
LUAI_FUNC unsigned int luaH_realasize (const Table *t);


#if defined(LUA_DEBUG)
LUAI_FUNC Node *luaH_mainposition (const Table *t, const TValue *key);
#endif


/* Access logging and filtering functions */

/**
 * @brief Enables or disables access logging.
 * @param L Lua state.
 * @param enable 1 to enable, 0 to disable.
 * @return Previous state.
 */
LUAI_FUNC int luaH_enable_access_log (lua_State *L, int enable);

/**
 * @brief Gets the path to the access log file.
 * @param L Lua state.
 * @return Log file path.
 */
LUAI_FUNC const char *luaH_get_log_path (lua_State *L);

/**
 * @brief Sets whether access filters are enabled.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_access_filter_enabled (int enabled);

/**
 * @brief Clears all access filters.
 */
LUAI_FUNC void luaH_clear_access_filters (void);

/**
 * @brief Adds an include key filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_include_key_filter (const char *pattern);

/**
 * @brief Adds an exclude key filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_exclude_key_filter (const char *pattern);

/**
 * @brief Adds an include value filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_include_value_filter (const char *pattern);

/**
 * @brief Adds an exclude value filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_exclude_value_filter (const char *pattern);

/**
 * @brief Adds an include operation filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_include_op_filter (const char *pattern);

/**
 * @brief Adds an exclude operation filter pattern.
 * @param pattern Glob pattern.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_exclude_op_filter (const char *pattern);

/**
 * @brief Sets the integer range for key filtering.
 * @param min_val Minimum value.
 * @param max_val Maximum value.
 */
LUAI_FUNC void luaH_set_key_int_range (int min_val, int max_val);

/**
 * @brief Sets the integer range for value filtering.
 * @param min_val Minimum value.
 * @param max_val Maximum value.
 */
LUAI_FUNC void luaH_set_value_int_range (int min_val, int max_val);

/**
 * @brief Enables or disables deduplication of log entries.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_dedup_enabled (int enabled);

/**
 * @brief Enables or disables showing only unique log entries.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_show_unique_only (int enabled);

/**
 * @brief Resets the deduplication cache.
 */
LUAI_FUNC void luaH_reset_dedup_cache (void);

/**
 * @brief Adds an include key type filter.
 * @param type Type name.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_include_key_type_filter (const char *type);

/**
 * @brief Adds an exclude key type filter.
 * @param type Type name.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_exclude_key_type_filter (const char *type);

/**
 * @brief Adds an include value type filter.
 * @param type Type name.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_include_value_type_filter (const char *type);

/**
 * @brief Adds an exclude value type filter.
 * @param type Type name.
 * @return 0 on success.
 */
LUAI_FUNC int luaH_add_exclude_value_type_filter (const char *type);

/**
 * @brief Sets intelligent mode for logging.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_intelligent_mode (int enabled);

/**
 * @brief Checks if intelligent mode is enabled.
 * @return 1 if enabled, 0 otherwise.
 */
LUAI_FUNC int luaH_is_intelligent_mode_enabled (void);

/**
 * @brief Sets whether to filter JNI environment pointers.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_filter_jnienv (int enabled);

/**
 * @brief Checks if JNI environment filtering is enabled.
 * @return 1 if enabled, 0 otherwise.
 */
LUAI_FUNC int luaH_is_filter_jnienv_enabled (void);

/**
 * @brief Sets whether to filter generic userdata.
 * @param enabled 1 to enable, 0 to disable.
 */
LUAI_FUNC void luaH_set_filter_userdata (int enabled);

/**
 * @brief Checks if userdata filtering is enabled.
 * @return 1 if enabled, 0 otherwise.
 */
LUAI_FUNC int luaH_is_filter_userdata_enabled (void);


#endif
