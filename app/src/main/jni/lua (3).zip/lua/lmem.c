/**
 * @file lmem.c
 * @brief Interface to Memory Manager.
 *
 * This file contains the implementation of the memory manager, including
 * generic allocation functions and the small object memory pool.
 */

#define lmem_c
#define LUA_CORE

#include "lprefix.h"


#include <stddef.h>

#include "lua.h"

#include "ldebug.h"
#include "ldo.h"
#include "lgc.h"
#include "lmem.h"
#include "lobject.h"
#include "lstate.h"



/*
** About the realloc function:
** void *frealloc (void *ud, void *ptr, size_t osize, size_t nsize);
** ('osize' is the old size, 'nsize' is the new size)
**
** - frealloc(ud, p, x, 0) frees the block 'p' and returns NULL.
** Particularly, frealloc(ud, NULL, 0, 0) does nothing,
** which is equivalent to free(NULL) in ISO C.
**
** - frealloc(ud, NULL, x, s) creates a new block of size 's'
** (no matter 'x'). Returns NULL if it cannot create the new block.
**
** - otherwise, frealloc(ud, b, x, y) reallocates the block 'b' from
** size 'x' to size 'y'. Returns NULL if it cannot reallocate the
** block to the new size.
*/


/*
** Macro to call the allocation function.
*/
#define callfrealloc(g,block,os,ns)    ((*g->frealloc)(g->ud, block, os, ns))


/*
** When an allocation fails, it will try again after an emergency
** collection, except when it cannot run a collection.  The GC should
** not be called while the state is not fully built, as the collector
** is not yet fully initialized. Also, it should not be called when
** 'gcstopem' is true, because then the interpreter is in the middle of
** a collection step.
*/
#define cantryagain(g)	(completestate(g) && !g->gcstopem)




#if defined(EMERGENCYGCTESTS)
/*
** First allocation will fail except when freeing a block (frees never
** fail) and when it cannot try again; this fail will trigger 'tryagain'
** and a full GC cycle at every allocation.
*/
static void *firsttry (global_State *g, void *block, size_t os, size_t ns) {
  if (ns > 0 && cantryagain(g))
    return NULL;  /* fail */
  else  /* normal allocation */
    return callfrealloc(g, block, os, ns);
}
#else
#define firsttry(g,block,os,ns)    callfrealloc(g, block, os, ns)
#endif





/*
** {=======================================================
** Functions to allocate/deallocate arrays for the Parser
** ========================================================
*/

/*
** Minimum size for arrays during parsing, to avoid overhead of
** reallocating to size 1, then 2, and then 4. All these arrays
** will be reallocated to exact sizes or erased when parsing ends.
*/
#define MINSIZEARRAY	4


/**
 * @brief Grows an array.
 *
 * @param L The Lua state.
 * @param block The current block.
 * @param nelems Number of elements needed.
 * @param psize Pointer to the current size (in elements).
 * @param size_elems Size of each element.
 * @param limit Maximum number of elements.
 * @param what Description of the array (for error messages).
 * @return The new block address.
 */
void *luaM_growaux_ (lua_State *L, void *block, int nelems, int *psize,
                     int size_elems, int limit, const char *what) {
  void *newblock;
  int size = *psize;
  if (nelems + 1 <= size)  /* does one extra element still fit? */
    return block;  /* nothing to be done */
  if (size >= limit / 2) {  /* cannot double it? */
    if (l_unlikely(size >= limit))  /* cannot grow even a little? */
      luaG_runerror(L, "too many %s (limit is %d)", what, limit);
    size = limit;  /* still have at least one free place */
  }
  else {
    size *= 2;
    if (size < MINSIZEARRAY)
      size = MINSIZEARRAY;  /* minimum size */
  }
  lua_assert(nelems + 1 <= size && size <= limit);
  /* 'limit' ensures that multiplication will not overflow */
  newblock = luaM_saferealloc_(L, block, cast_sizet(*psize) * size_elems,
                                         cast_sizet(size) * size_elems);
  *psize = size;  /* update only when everything else is OK */
  return newblock;
}


/**
 * @brief Shrinks an array.
 *
 * @param L The Lua state.
 * @param block The current block.
 * @param size Pointer to the current size (in elements).
 * @param final_n Final number of elements.
 * @param size_elem Size of each element.
 * @return The new block address.
 */
void *luaM_shrinkvector_ (lua_State *L, void *block, int *size,
                          int final_n, int size_elem) {
  void *newblock;
  size_t oldsize = cast_sizet((*size) * size_elem);
  size_t newsize = cast_sizet(final_n * size_elem);
  lua_assert(newsize <= oldsize);
  newblock = luaM_saferealloc_(L, block, oldsize, newsize);
  *size = final_n;
  return newblock;
}

/* }======================================================= */


/**
 * @brief Raises a memory allocation error.
 *
 * @param L The Lua state.
 * @return Never returns.
 */
l_noret luaM_toobig (lua_State *L) {
  luaG_runerror(L, "memory allocation error: block too big");
}


/**
 * @brief Frees a memory block.
 *
 * @param L The Lua state.
 * @param block The block to free.
 * @param osize The size of the block.
 */
void luaM_free_ (lua_State *L, void *block, size_t osize) {
  global_State *g = G(L);
  lua_assert((osize == 0) == (block == NULL));
  callfrealloc(g, block, osize, 0);
  l_atomic_sub(&g->GCdebt, osize);
}


/*
** In case of allocation fail, this function will do an emergency
** collection to free some memory and then try the allocation again.
*/
static void *tryagain (lua_State *L, void *block,
                       size_t osize, size_t nsize) {
  global_State *g = G(L);
  if (cantryagain(g)) {
    luaC_fullgc(L, 1);  /* try to free some memory... */
    return callfrealloc(g, block, osize, nsize);  /* try again */
  }
  else return NULL;  /* cannot run an emergency collection */
}


/**
 * @brief Reallocates a memory block.
 *
 * @param L The Lua state.
 * @param block The current block.
 * @param osize The old size.
 * @param nsize The new size.
 * @return The new block address, or NULL on failure.
 */
void *luaM_realloc_ (lua_State *L, void *block, size_t osize, size_t nsize) {
  void *newblock;
  global_State *g = G(L);
  lua_assert((osize == 0) == (block == NULL));
  newblock = firsttry(g, block, osize, nsize);
  if (l_unlikely(newblock == NULL && nsize > 0)) {
    newblock = tryagain(L, block, osize, nsize);
    if (newblock == NULL)  /* still no memory? */
      return NULL;  /* do not update 'GCdebt' */
  }
  lua_assert((nsize == 0) == (newblock == NULL));
  l_atomic_add(&g->GCdebt, (l_mem)(nsize - osize));
  return newblock;
}


/**
 * @brief Reallocates a memory block, raising an error on failure.
 *
 * @param L The Lua state.
 * @param block The current block.
 * @param osize The old size.
 * @param nsize The new size.
 * @return The new block address.
 */
void *luaM_saferealloc_ (lua_State *L, void *block, size_t osize,
                                                    size_t nsize) {
  void *newblock = luaM_realloc_(L, block, osize, nsize);
  if (l_unlikely(newblock == NULL && nsize > 0))  /* allocation failed? */
    luaM_error(L);
  return newblock;
}


/**
 * @brief Allocates a new memory block.
 *
 * @param L The Lua state.
 * @param size The size to allocate.
 * @param tag The tag for the block (unused in standard Lua, but passed to allocator).
 * @return The new block address.
 */
void *luaM_malloc_ (lua_State *L, size_t size, int tag) {
  if (size == 0)
    return NULL;  /* that's all */
  else {
    global_State *g = G(L);
    void *newblock = firsttry(g, NULL, tag, size);
    if (l_unlikely(newblock == NULL)) {
      newblock = tryagain(L, NULL, tag, size);
      if (newblock == NULL)
        luaM_error(L);
    }
    l_atomic_add(&g->GCdebt, size);
    return newblock;
  }
}


/*
** ========================================================
** Memory Pool Implementation for Small Objects
** ========================================================
*/

static const size_t size_classes[NUM_SIZE_CLASSES] = {
  8, 16, 24, 32, 48, 64, 96, 128, 192, 256, 512, 1024
};

static int get_size_class (size_t size) {
  int lo = 0, hi = NUM_SIZE_CLASSES - 1;
  while (lo < hi) {
    int mid = (lo + hi) >> 1;
    if (size_classes[mid] >= size)
      hi = mid;
    else
      lo = mid + 1;
  }
  if (lo < NUM_SIZE_CLASSES && size_classes[lo] >= size)
    return lo;
  return -1;
}

/**
 * @brief Initializes the memory pool.
 *
 * @param L The Lua state.
 */
void luaM_poolinit (lua_State *L) {
  global_State *g = G(L);
  int i;
  for (i = 0; i < NUM_SIZE_CLASSES; i++) {
    g->mempool.pools[i].free_list = NULL;
    g->mempool.pools[i].object_size = size_classes[i];
    g->mempool.pools[i].max_cache = 64;
    g->mempool.pools[i].current_count = 0;
    g->mempool.pools[i].total_alloc = 0;
    g->mempool.pools[i].total_hit = 0;
  }
  g->mempool.threshold = size_classes[NUM_SIZE_CLASSES - 1];
  g->mempool.fallback_alloc = g->frealloc;
  g->mempool.fallback_ud = g->ud;
  g->mempool.enabled = 1;
  g->mempool.small_limit = size_classes[NUM_SIZE_CLASSES - 1];
  l_mutex_init(&g->mempool.lock);
}

/**
 * @brief Shuts down the memory pool, freeing all cached blocks.
 *
 * @param L The Lua state.
 */
void luaM_poolshutdown (lua_State *L) {
  global_State *g = G(L);
  int i;
  l_mutex_lock(&g->mempool.lock);
  for (i = 0; i < NUM_SIZE_CLASSES; i++) {
    MemPool *pool = &g->mempool.pools[i];
    void *block = pool->free_list;
    while (block) {
      void *next = *(void **)block;
      callfrealloc(g, block, pool->object_size, 0);
      block = next;
    }
    pool->free_list = NULL;
    pool->current_count = 0;
  }
  g->mempool.enabled = 0;
  l_mutex_unlock(&g->mempool.lock);
  l_mutex_destroy(&g->mempool.lock);
}

/**
 * @brief Allocates a block from the memory pool.
 *
 * @param L The Lua state.
 * @param size The size to allocate.
 * @return The allocated block, or NULL if allocation failed.
 */
void *luaM_poolalloc (lua_State *L, size_t size) {
  global_State *g = G(L);
  if (!g->mempool.enabled || size == 0)
    return NULL;

  int idx = get_size_class(size);
  if (idx < 0)
    return NULL;

  l_mutex_lock(&g->mempool.lock);
  MemPool *pool = &g->mempool.pools[idx];
  pool->total_alloc++;

  if (pool->free_list != NULL) {
    void *block = pool->free_list;
    pool->free_list = *(void **)block;
    pool->current_count--;
    pool->total_hit++;
    l_mutex_unlock(&g->mempool.lock);
    return block;
  }
  l_mutex_unlock(&g->mempool.lock);

  void *block = callfrealloc(g, NULL, 0, pool->object_size);
  if (block == NULL)
    return NULL;

  l_atomic_add(&g->GCdebt, pool->object_size);
  return block;
}

/**
 * @brief Frees a block to the memory pool.
 *
 * @param L The Lua state.
 * @param block The block to free.
 * @param size The size of the block.
 */
void luaM_poolfree (lua_State *L, void *block, size_t size) {
  global_State *g = G(L);
  if (!g->mempool.enabled || block == NULL || size == 0)
    return;

  int idx = get_size_class(size);
  if (idx < 0) {
    luaM_free_(L, block, size);
    return;
  }

  l_mutex_lock(&g->mempool.lock);
  MemPool *pool = &g->mempool.pools[idx];

  if (pool->current_count >= pool->max_cache) {
    l_mutex_unlock(&g->mempool.lock);
    luaM_free_(L, block, pool->object_size);
    return;
  }

  *(void **)block = pool->free_list;
  pool->free_list = block;
  pool->current_count++;
  l_mutex_unlock(&g->mempool.lock);
}

/**
 * @brief Shrinks the memory pool by freeing excess cached blocks.
 *
 * @param L The Lua state.
 */
void luaM_poolshrink (lua_State *L) {
  global_State *g = G(L);
  int i;
  l_mutex_lock(&g->mempool.lock);
  for (i = 0; i < NUM_SIZE_CLASSES; i++) {
    MemPool *pool = &g->mempool.pools[i];
    int target = pool->max_cache >> 1;
    while (pool->current_count > target && pool->free_list != NULL) {
      void *block = pool->free_list;
      pool->free_list = *(void **)block;
      pool->current_count--;

      // We must unlock to free, because luaM_free_ might want to update GCdebt or do other things.
      // But wait, luaM_free_ calls callfrealloc, which is just realloc/free.
      // It does atomic_sub GCdebt.
      // However, if we simply free it here while holding the lock, it is safe as long as free doesn't re-enter pool.
      // Standard free does not.
      // But we are in poolshrink, which is called during GC?
      // luaM_poolgc calls this.
      // Let's check if it's safe to hold lock. Yes, it should be.

      callfrealloc(g, block, pool->object_size, 0);
      l_atomic_sub(&g->GCdebt, pool->object_size);
    }
  }
  l_mutex_unlock(&g->mempool.lock);
}

/**
 * @brief Performs garbage collection on the memory pool (shrinks it).
 *
 * @param L The Lua state.
 */
void luaM_poolgc (lua_State *L) {
  luaM_poolshrink(L);
}

/**
 * @brief Returns the total memory usage of the memory pool.
 *
 * @param L The Lua state.
 * @return Total memory used by cached blocks.
 */
size_t luaM_poolgetusage (lua_State *L) {
  global_State *g = G(L);
  size_t total = 0;
  int i;
  l_mutex_lock(&g->mempool.lock);
  for (i = 0; i < NUM_SIZE_CLASSES; i++) {
    MemPool *pool = &g->mempool.pools[i];
    total += pool->current_count * pool->object_size;
  }
  l_mutex_unlock(&g->mempool.lock);
  return total;
}
