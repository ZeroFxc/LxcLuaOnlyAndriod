/*
** $Id: ltablib.c $
** Library for Table Manipulation
** See Copyright Notice in lua.h
*/

#define ltablib_c
#define LUA_LIB

#include "lprefix.h"


#include <limits.h>
#include <stddef.h>
#include <string.h>

#include "lua.h"

#include "lauxlib.h"
#include "lualib.h"
#include "llimits.h"

#include "lstate.h"
#include "lobject.h"


/*
** Operations that an object must define to mimic a table
** (some functions only need some of them)
*/
#define TAB_R	1			/* read */
#define TAB_W	2			/* write */
#define TAB_L	4			/* length */
#define TAB_RW	(TAB_R | TAB_W)		/* read/write */


#define aux_getn(L,n,w)	(checktab(L, n, (w) | TAB_L), luaL_len(L, n))


static int checkfield (lua_State *L, const char *key, int n) {
  lua_pushstring(L, key);
  return (lua_rawget(L, -n) != LUA_TNIL);
}


/*
** Check that 'arg' either is a table or can behave like one (that is,
** has a metatable with the required metamethods)
*/
static void checktab (lua_State *L, int arg, int what) {
  if (lua_type(L, arg) != LUA_TTABLE) {  /* is it not a table? */
    int n = 1;  /* number of elements to pop */
    if (lua_getmetatable(L, arg) &&  /* must have metatable */
        (!(what & TAB_R) || checkfield(L, "__index", ++n)) &&
        (!(what & TAB_W) || checkfield(L, "__newindex", ++n)) &&
        (!(what & TAB_L) || checkfield(L, "__len", ++n))) {
      lua_pop(L, n);  /* pop metatable and tested metamethods */
    }
    else
      luaL_checktype(L, arg, LUA_TTABLE);  /* force an error */
  }
}

//mod DifierLine
#if defined(LUA_COMPAT_MAXN)
static int maxn (lua_State *L) {
  lua_Number max = 0;
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_pushnil(L);  /* first key */
  while (lua_next(L, 1)) {
    lua_pop(L, 1);  /* remove value */
    if (lua_type(L, -1) == LUA_TNUMBER) {
      lua_Number v = lua_tonumber(L, -1);
      if (v > max) max = v;
    }
  }
  lua_pushnumber(L, max);
  return 1;
}

static int size (lua_State *L) {
  lua_Integer i = 0;
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_pushnil(L);  /* first key */
  while (lua_next(L, 1)) {
    lua_pop(L, 1);  /* remove value */
    i++;
   }
  lua_pushinteger(L, i);
  return 1;
}

static int clear (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_pushnil(L);  /* first key */
  while (lua_next(L, 1)) {
    lua_pop(L, 1);  /* remove value */
    lua_pushvalue(L,-1);
    lua_pushnil(L);
    lua_settable(L,-4);
   }
  return 0;
}

static int find (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_pushvalue(L,3);  /* first key */
  while (lua_next(L, 1)) {
    if(lua_rawequal(L,-1,2)){
      lua_pop(L,1);
      return 1;
    }
    lua_pop(L, 1);  /* remove value */
  }
  lua_pushnil(L);
  return 1;
}

static int gfind_aux (lua_State *L) {
  lua_settop(L,0);
  lua_pushvalue(L,lua_upvalueindex(1));
  lua_pushvalue(L,lua_upvalueindex(2));
  lua_pushvalue(L,lua_upvalueindex(3));
  while (lua_next(L, 1)) {
    if(lua_rawequal(L,-1,2)){
      lua_pop(L,1);
      lua_pushvalue(L,-1);
      lua_replace(L, lua_upvalueindex(3));
      return 1;
    }
    lua_pop(L, 1);  /* remove value */
  }
  return 0;
}

static int gfind (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  if(lua_gettop(L)==2)
      lua_pushnil(L);
  lua_pushcclosure(L,gfind_aux,3);
  return 1;
}

static int clone_aux (lua_State *L,int idx) {
    luaL_checktype(L, idx, LUA_TTABLE);
    const char *id = lua_pushfstring(L, "%p",
                                      lua_topointer(L, idx));
    lua_gettable(L,1);
    if(lua_type(L,-1)!=LUA_TNIL){
        lua_remove(L,idx);
        return 1;
    }
    lua_remove(L,idx+1);
    lua_newtable(L);
    lua_pushvalue(L,-1);
    lua_setfield(L,1,id);
    lua_pushnil(L);  /* first key */
    while (lua_next(L, idx)) {
        if(lua_type(L,idx+3)==LUA_TTABLE)
           clone_aux(L,idx+3);
        lua_pushvalue(L,idx+2);
        lua_insert(L,idx+2);
        lua_settable(L,idx+1);
    }
    if(lua_getmetatable(L,idx))
      lua_setmetatable(L,idx+1);
    lua_remove(L,idx);
    return 1;
}

static int t_clone (lua_State *L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    lua_newtable(L);
    lua_insert(L,1);
    clone_aux(L,2);
    lua_remove(L,1);
  return 1;
}

static int tconst (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_concat(L,1);
  return 1;
}
#endif
//---

static int tinsert (lua_State *L) {
  lua_Integer pos;  /* where to insert new element */
  lua_Integer e;

  if (lua_gettop(L) == 3) {
      pos = luaL_checkinteger(L, 2);
  }

  lua_locktable(L, 1);
  e = aux_getn(L, 1, TAB_RW);
  e = luaL_intop(+, e, 1);  /* first empty element */

  switch (lua_gettop(L)) {
    case 2: {  /* called with only 2 arguments */
      pos = e;  /* insert new element at the end */
      break;
    }
    case 3: {
      lua_Integer i;
      if (!((lua_Unsigned)pos - 1u < (lua_Unsigned)e)) { lua_unlocktable(L, 1); return luaL_argerror(L, 2, "position out of bounds"); }
      for (i = e; i > pos; i--) {  /* move up elements */
        lua_rawgeti(L, 1, i - 1);
        lua_rawseti(L, 1, i);  /* t[i] = t[i - 1] */
      }
      break;
    }
    default: {
      lua_unlocktable(L, 1);
      return luaL_error(L, "'insert' 参数数量错误");
    }
  }
  lua_pushvalue(L, -1);
  lua_rawseti(L, 1, pos);  /* t[pos] = v */
  lua_unlocktable(L, 1);
  return 0;
}


static int tremove (lua_State *L) {
  lua_Integer size = aux_getn(L, 1, TAB_RW);
  lua_Integer pos = luaL_optinteger(L, 2, size);

  lua_locktable(L, 1);
  size = aux_getn(L, 1, TAB_RW);
  if (lua_gettop(L) <= 1) { pos = size; }

  if (pos != size) { /* validate 'pos' if given */
    if (!((lua_Unsigned)pos - 1u <= (lua_Unsigned)size)) { lua_unlocktable(L, 1); return luaL_argerror(L, 2, "position out of bounds"); }
  }
  lua_rawgeti(L, 1, pos);  /* result = t[pos] */
  for ( ; pos < size; pos++) {
    lua_rawgeti(L, 1, pos + 1);
    lua_rawseti(L, 1, pos);  /* t[pos] = t[pos + 1] */
  }
  lua_pushnil(L);
  lua_rawseti(L, 1, pos);  /* remove entry t[pos] */
  lua_unlocktable(L, 1);
  return 1;
}


/*
** Copy elements (1[f], ..., 1[e]) into (tt[t], tt[t+1], ...). Whenever
** possible, copy in increasing order, which is better for rehashing.
** "possible" means destination after original range, or smaller
** than origin, or copying to another table.
*/
static int tmove (lua_State *L) {
  lua_Integer f = luaL_checkinteger(L, 2);
  lua_Integer e = luaL_checkinteger(L, 3);
  lua_Integer t = luaL_checkinteger(L, 4);
  int tt = !lua_isnoneornil(L, 5) ? 5 : 1;  /* destination table */
  checktab(L, 1, TAB_R);
  checktab(L, tt, TAB_W);
  if (e >= f) {  /* otherwise, nothing to move */
    lua_Integer n, i;
    luaL_argcheck(L, f > 0 || e < LUA_MAXINTEGER + f, 3,
                  "too many elements to move");
    n = e - f + 1;  /* number of elements to move */
    luaL_argcheck(L, t <= LUA_MAXINTEGER - n + 1, 4,
                  "destination wrap around");
    if (t > e || t <= f || (tt != 1 && !lua_compare(L, 1, tt, LUA_OPEQ))) {
      for (i = 0; i < n; i++) {
        lua_geti(L, 1, f + i);
        lua_seti(L, tt, t + i);
      }
    }
    else {
      for (i = n - 1; i >= 0; i--) {
        lua_geti(L, 1, f + i);
        lua_seti(L, tt, t + i);
      }
    }
  }
  lua_pushvalue(L, tt);  /* return destination table */
  return 1;
}


static void addfield (lua_State *L, luaL_Buffer *b, lua_Integer i) {
  lua_geti(L, 1, i);
  if (l_unlikely(!lua_isstring(L, -1)))
    luaL_error(L, "'concat' 表中索引 %I 的值无效 (%s)",
                  luaL_typename(L, -1), (LUAI_UACINT)i);
  luaL_addvalue(b);
}


static int tconcat (lua_State *L) {
  luaL_Buffer b;
  lua_Integer last = aux_getn(L, 1, TAB_R);
  size_t lsep;
  const char *sep = luaL_optlstring(L, 2, "", &lsep);
  lua_Integer i = luaL_optinteger(L, 3, 1);
  last = luaL_optinteger(L, 4, last);
  luaL_buffinit(L, &b);
  for (; i < last; i++) {
    addfield(L, &b, i);
    luaL_addlstring(&b, sep, lsep);
  }
  if (i == last)  /* add last value (if interval was not empty) */
    addfield(L, &b, i);
  luaL_pushresult(&b);
  return 1;
}


/*
** {===========================================
** Pack/unpack
** ============================================
*/

static int tpack (lua_State *L) {
  int i;
  int n = lua_gettop(L);  /* number of elements to pack */
  lua_createtable(L, n, 1);  /* create result table */
  lua_insert(L, 1);  /* put it at index 1 */
  for (i = n; i >= 1; i--)  /* assign elements */
    lua_seti(L, 1, i);
  lua_pushinteger(L, n);
  lua_setfield(L, 1, "n");  /* t.n = number of elements */
  return 1;  /* return table */
}


static int tunpack (lua_State *L) {
  lua_Unsigned n;
  lua_Integer i = luaL_optinteger(L, 2, 1);
  lua_Integer e = luaL_opt(L, luaL_checkinteger, 3, luaL_len(L, 1));
  if (i > e) return 0;  /* empty range */
  n = (lua_Unsigned)e - i;  /* number of elements minus 1 (avoid overflows) */
  if (l_unlikely(n >= (unsigned int)INT_MAX  ||
                 !lua_checkstack(L, (int)(++n))))
    return luaL_error(L, "解包结果过多");
  for (; i < e; i++) {  /* push arg[i..e - 1] (to avoid overflows) */
    lua_geti(L, 1, i);
  }
  lua_geti(L, 1, e);  /* push last element */
  return (int)n;
}

/* }=========================================== */



/*
** {===========================================
** Quicksort
** (based on 'Algorithms in MODULA-3', Robert Sedgewick;
**  Addison-Wesley, 1993.)
** ============================================
*/


/* type for array indices */
typedef unsigned int IdxT;


/*
** Produce a "random" 'unsigned int' to randomize pivot choice. This
** macro is used only when 'sort' detects a big imbalance in the result
** of a partition. (If you don't want/need this "randomness", ~0 is a
** good choice.)
*/
#if !defined(l_randomizePivot)		/* { */

#include <time.h>

/* size of 'e' measured in number of 'unsigned int's */
#define sof(e)		(sizeof(e) / sizeof(unsigned int))

/*
** Use 'time' and 'clock' as sources of "randomness". Because we don't
** know the types 'clock_t' and 'time_t', we cannot cast them to
** anything without risking overflows. A safe way to use their values
** is to copy them to an array of a known type and use the array values.
*/
static unsigned int l_randomizePivot (void) {
  clock_t c = clock();
  time_t t = time(NULL);
  unsigned int buff[sof(c) + sof(t)];
  unsigned int i, rnd = 0;
  memcpy(buff, &c, sof(c) * sizeof(unsigned int));
  memcpy(buff + sof(c), &t, sof(t) * sizeof(unsigned int));
  for (i = 0; i < sof(buff); i++)
    rnd += buff[i];
  return rnd;
}

#endif					/* } */


/* arrays larger than 'RANLIMIT' may use randomized pivots */
#define RANLIMIT	100u


static void set2 (lua_State *L, IdxT i, IdxT j) {
  lua_seti(L, 1, i);
  lua_seti(L, 1, j);
}


/*
** Return true iff value at stack index 'a' is less than the value at
** index 'b' (according to the order of the sort).
*/
static int sort_comp (lua_State *L, int a, int b) {
  if (lua_isnil(L, 2))  /* no function? */
    return lua_compare(L, a, b, LUA_OPLT);  /* a < b */
  else {  /* function */
    int res;
    lua_pushvalue(L, 2);    /* push function */
    lua_pushvalue(L, a-1);  /* -1 to compensate function */
    lua_pushvalue(L, b-2);  /* -2 to compensate function and 'a' */
    lua_call(L, 2, 1);      /* call function */
    res = lua_toboolean(L, -1);  /* get result */
    lua_pop(L, 1);          /* pop result */
    return res;
  }
}


/*
** Does the partition: Pivot P is at the top of the stack.
** precondition: a[lo] <= P == a[up-1] <= a[up],
** so it only needs to do the partition from lo + 1 to up - 2.
** Pos-condition: a[lo .. i - 1] <= a[i] == P <= a[i + 1 .. up]
** returns 'i'.
*/
static IdxT partition (lua_State *L, IdxT lo, IdxT up) {
  IdxT i = lo;  /* will be incremented before first use */
  IdxT j = up - 1;  /* will be decremented before first use */
  /* loop invariant: a[lo .. i] <= P <= a[j .. up] */
  for (;;) {
    /* next loop: repeat ++i while a[i] < P */
    while ((void)lua_geti(L, 1, ++i), sort_comp(L, -1, -2)) {
      if (l_unlikely(i == up - 1))  /* a[up - 1] < P == a[up - 1] */
        luaL_error(L, "排序的顺序函数无效");
      lua_pop(L, 1);  /* remove a[i] */
    }
    /* after the loop, a[i] >= P and a[lo .. i - 1] < P  (a) */
    /* next loop: repeat --j while P < a[j] */
    while ((void)lua_geti(L, 1, --j), sort_comp(L, -3, -1)) {
      if (l_unlikely(j < i))  /* j <= i - 1 and a[j] > P, contradicts (a) */
        luaL_error(L, "排序的顺序函数无效");
      lua_pop(L, 1);  /* remove a[j] */
    }
    /* after the loop, a[j] <= P and a[j + 1 .. up] >= P */
    if (j < i) {  /* no elements out of place? */
      /* a[lo .. i - 1] <= P <= a[j + 1 .. i .. up] */
      lua_pop(L, 1);  /* pop a[j] */
      /* swap pivot (a[up - 1]) with a[i] to satisfy pos-condition */
      set2(L, up - 1, i);
      return i;
    }
    /* otherwise, swap a[i] - a[j] to restore invariant and repeat */
    set2(L, i, j);
  }
}


/*
** Choose an element in the middle (2nd-3th quarters) of [lo,up]
** "randomized" by 'rnd'
*/
static IdxT choosePivot (IdxT lo, IdxT up, unsigned int rnd) {
  IdxT r4 = (up - lo) / 4;  /* range/4 */
  IdxT p = (rnd ^ lo ^ up) % (r4 * 2) + (lo + r4);
  lua_assert(lo + r4 <= p && p <= up - r4);
  return p;
}


/*
** Quicksort algorithm (recursive function)
*/
static void auxsort (lua_State *L, IdxT lo, IdxT up,
                                   unsigned int rnd) {
  while (lo < up) {  /* loop for tail recursion */
    IdxT p;  /* Pivot index */
    IdxT n;  /* to be used later */
    /* sort elements 'lo', 'p', and 'up' */
    lua_geti(L, 1, lo);
    lua_geti(L, 1, up);
    if (sort_comp(L, -1, -2))  /* a[up] < a[lo]? */
      set2(L, lo, up);  /* swap a[lo] - a[up] */
    else
      lua_pop(L, 2);  /* remove both values */
    if (up - lo == 1)  /* only 2 elements? */
      return;  /* already sorted */
    if (up - lo < RANLIMIT || rnd == 0)  /* small interval or no randomize? */
      p = (lo + up)/2;  /* middle element is a good pivot */
    else  /* for larger intervals, it is worth a random pivot */
      p = choosePivot(lo, up, rnd);
    lua_geti(L, 1, p);
    lua_geti(L, 1, lo);
    if (sort_comp(L, -2, -1))  /* a[p] < a[lo]? */
      set2(L, p, lo);  /* swap a[p] - a[lo] */
    else {
      lua_pop(L, 1);  /* remove a[lo] */
      lua_geti(L, 1, up);
      if (sort_comp(L, -1, -2))  /* a[up] < a[p]? */
        set2(L, p, up);  /* swap a[up] - a[p] */
      else
        lua_pop(L, 2);
    }
    if (up - lo == 2)  /* only 3 elements? */
      return;  /* already sorted */
    lua_geti(L, 1, p);  /* get middle element (Pivot) */
    lua_pushvalue(L, -1);  /* push Pivot */
    lua_geti(L, 1, up - 1);  /* push a[up - 1] */
    set2(L, p, up - 1);  /* swap Pivot (a[p]) with a[up - 1] */
    p = partition(L, lo, up);
    /* a[lo .. p - 1] <= a[p] == P <= a[p + 1 .. up] */
    if (p - lo < up - p) {  /* lower interval is smaller? */
      auxsort(L, lo, p - 1, rnd);  /* call recursively for lower interval */
      n = p - lo;  /* size of smaller interval */
      lo = p + 1;  /* tail call for [p + 1 .. up] (upper interval) */
    }
    else {
      auxsort(L, p + 1, up, rnd);  /* call recursively for upper interval */
      n = up - p;  /* size of smaller interval */
      up = p - 1;  /* tail call for [lo .. p - 1]  (lower interval) */
    }
    if ((up - lo) / 128 > n) /* partition too imbalanced? */
      rnd = l_randomizePivot();  /* try a new randomization */
  }  /* tail call auxsort(L, lo, up, rnd) */
}


static int sort (lua_State *L) {
  lua_Integer n = aux_getn(L, 1, TAB_RW);
  if (n > 1) {  /* non-trivial interval? */
    luaL_argcheck(L, n < INT_MAX, 1, "array too big");
    if (!lua_isnoneornil(L, 2))  /* is there a 2nd argument? */
      luaL_checktype(L, 2, LUA_TFUNCTION);  /* must be a function */
    lua_settop(L, 2);  /* make sure there are two arguments */
    auxsort(L, 1, (IdxT)n, 0);
  }
  return 0;
}


//mod DifierLine
#if defined(LUA_COMPAT_FOREACH)
static int foreachi (lua_State *L) {
  int i;
  lua_Integer n = aux_getn(L, 1, TAB_RW);
  luaL_checktype(L, 2, LUA_TFUNCTION);
  for (i=1; i <= n; i++) {
    lua_pushvalue(L, 2);  /* function */
    lua_pushinteger(L, i);  /* 1st argument */
    lua_rawgeti(L, 1, i);  /* 2nd argument */
    lua_call(L, 2, 1);
    if (!lua_isnil(L, -1))
      return 1;
    lua_pop(L, 1);  /* remove nil result */
  }
  return 0;
}


static int foreach (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  luaL_checktype(L, 2, LUA_TFUNCTION);
  lua_pushnil(L);  /* first key */
  while (lua_next(L, 1)) {
    lua_pushvalue(L, 2);  /* function */
    lua_pushvalue(L, -3);  /* key */
    lua_pushvalue(L, -3);  /* value */
    lua_call(L, 2, 1);
    if (!lua_isnil(L, -1))
      return 1;
    lua_pop(L, 2);  /* remove value and result */
  }
  return 0;
}
#endif


/* }=========================================== */


static int tadd (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  int n = lua_gettop(L);
  int added = 0;
  for (int i = 2; i <= n; i++) {
    int found = 0;
    lua_pushnil(L);
    while (lua_next(L, 1)) {
      if (lua_rawequal(L, -1, i)) {
        found = 1;
        lua_pop(L, 1);
        break;
      }
      lua_pop(L, 1);
    }
    if (!found) {
      lua_pushvalue(L, i);
      lua_rawseti(L, 1, luaL_len(L, 1) + 1);
      added++;
    }
  }
  lua_pushinteger(L, added);
  return 1;
}

static int tcreate (lua_State *L) {
  lua_Integer narr = luaL_optinteger(L, 1, 0);  /* 数组部分大小 */
  lua_Integer nrec = luaL_optinteger(L, 2, 0);  /* 哈希表部分大小 */
  lua_createtable(L, (int)narr, (int)nrec);  /* 创建新表，预分配空间 */
  return 1;
}


static int tkeys (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_Integer n = 0;
  lua_newtable(L);
  lua_pushnil(L);
  while (lua_next(L, 1)) {
    n++;
    lua_pushvalue(L, -2);
    lua_rawseti(L, -2, n);
    lua_pop(L, 1);
  }
  return 1;
}


static int tvals (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_Integer n = 0;
  lua_newtable(L);
  lua_pushnil(L);
  while (lua_next(L, 1)) {
    n++;
    lua_pushvalue(L, -1);
    lua_rawseti(L, -2, n);
    lua_pop(L, 1);
  }
  return 1;
}


static int tfill (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_Integer start = luaL_optinteger(L, 2, 1);
  lua_Integer end = luaL_optinteger(L, 3, 0);
  if (end == 0) {
    end = aux_getn(L, 1, TAB_R);
  }
  luaL_argcheck(L, start >= 1, 2, "position out of bounds");
  luaL_argcheck(L, end >= start - 1, 3, "position out of bounds");
  for (lua_Integer i = start; i <= end; i++) {
    lua_pushvalue(L, 4);
    lua_rawseti(L, 1, i);
  }
  return 0;
}

static int t_concat_op (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  luaL_checktype(L, 2, LUA_TTABLE);
  lua_newtable(L);
  int idx = 1;
  int n1 = luaL_len(L, 1);
  for(int i=1; i<=n1; i++) {
    lua_geti(L, 1, i);
    lua_seti(L, -2, idx++);
  }
  int n2 = luaL_len(L, 2);
  for(int i=1; i<=n2; i++) {
    lua_geti(L, 2, i);
    lua_seti(L, -2, idx++);
  }
  return 1;
}

static int t_add_op (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  luaL_checktype(L, 2, LUA_TTABLE);
  lua_newtable(L); /* Result at 3 */
  int idx = 1;
  lua_newtable(L); /* seen at 4 */
  int n1 = luaL_len(L, 1);
  for(int i=1; i<=n1; i++) {
    lua_geti(L, 1, i);
    lua_pushvalue(L, -1);
    lua_gettable(L, 4); /* Check seen */
    if(lua_isnil(L, -1)) {
      lua_pop(L, 1);
      lua_pushvalue(L, -1);
      lua_seti(L, 3, idx++); /* Add to Result */
      lua_pushvalue(L, -1);
      lua_pushboolean(L, 1);
      lua_settable(L, 4); /* Add to seen */
    } else {
      lua_pop(L, 1);
    }
    lua_pop(L, 1);
  }
  int n2 = luaL_len(L, 2);
  for(int i=1; i<=n2; i++) {
    lua_geti(L, 2, i);
    lua_pushvalue(L, -1);
    lua_gettable(L, 4);
    if(lua_isnil(L, -1)) {
      lua_pop(L, 1);
      lua_pushvalue(L, -1);
      lua_seti(L, 3, idx++);
      lua_pushvalue(L, -1);
      lua_pushboolean(L, 1);
      lua_settable(L, 4);
    } else {
      lua_pop(L, 1);
    }
    lua_pop(L, 1);
  }
  lua_pop(L, 1);
  return 1;
}

static int t_sub_op (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  luaL_checktype(L, 2, LUA_TTABLE);
  lua_newtable(L); /* Result at 3 */
  int idx = 1;
  lua_newtable(L); /* exclude at 4 */
  int n2 = luaL_len(L, 2);
  for(int i=1; i<=n2; i++) {
    lua_geti(L, 2, i);
    lua_pushboolean(L, 1);
    lua_settable(L, 4);
  }
  int n1 = luaL_len(L, 1);
  for(int i=1; i<=n1; i++) {
    lua_geti(L, 1, i);
    lua_pushvalue(L, -1);
    lua_gettable(L, 4);
    if(lua_isnil(L, -1)) {
      lua_pop(L, 1);
      lua_pushvalue(L, -1);
      lua_seti(L, 3, idx++);
    } else {
      lua_pop(L, 1);
    }
    lua_pop(L, 1);
  }
  lua_pop(L, 1);
  return 1;
}

static int t_share (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  TValue *o = s2v(L->ci->func.p + 1);
  Table *t = hvalue(o);
  t->is_shared = 1;
  lua_pushvalue(L, 1);
  return 1;
}

static const luaL_Reg tab_funcs[] = {
	{"share", t_share},
	{"concat", tconcat},
#if defined(LUA_COMPAT_FOREACH)
	{"foreach", foreach},
	{"foreachi", foreachi},
#endif
#if defined(LUA_COMPAT_MAXN)
	{"maxn", maxn},
	{"size", size},
	{"clear", clear},
	{"find", find},
	{"gfind", gfind},
	{"clone", t_clone},
	{"const", tconst},
#endif
	{"add", tadd},
	{"create", tcreate},
	{"keys", tkeys},
	{"vals", tvals},
	{"fill", tfill},
	{"insert", tinsert},
	{"pack", tpack},
	{"unpack", tunpack},
	{"remove", tremove},
	{"move", tmove},
	{"sort", sort},
	{NULL, NULL}
};


LUAMOD_API int luaopen_table (lua_State *L) {
    luaL_newlib(L, tab_funcs);

    /* create default metatable for tables */
    lua_newtable(L);
    lua_pushvalue(L, -2);
    lua_setfield(L, -2, "__index");  /* mt.__index = table */
    lua_pushcfunction(L, t_concat_op);
    lua_setfield(L, -2, "__concat");
    lua_pushcfunction(L, t_add_op);
    lua_setfield(L, -2, "__add");
    lua_pushcfunction(L, t_sub_op);
    lua_setfield(L, -2, "__sub");

    /* set it as the default metatable for tables */
    G(L)->mt[LUA_TTABLE] = gcvalue(s2v(L->top.p - 1));

    lua_pop(L, 1); /* pop metatable */

    /* set an empty metatable for the table library itself to prevent infinite loops
       in __index lookups (since it is the __index target) */
    lua_newtable(L);
    lua_setmetatable(L, -2);

#if defined(LUA_COMPAT_UNPACK)
    /* _G.unpack = table.unpack */
  lua_getfield(L, -1, "unpack");
  lua_setglobal(L, "unpack");
#endif
    return 1;
}

